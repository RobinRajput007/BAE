<?php 
if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Admin_model extends CI_Model
{
	 function __construct(){ 
        parent::__construct(); 
        $this->load->database(); 
        date_default_timezone_set("Asia/Calcutta");
    }


    //=========== Get All Registered Students Data Function 24-07-19============//
    public function getAllStudents(){
     $Data = $this->db->select('user_register.*,user_role.user_id,user_role.role,user_role.permission,student_profile.profile_pic,
                               student_profile.image_url')
                      ->from('user_register')
                      ->join('user_role','user_role.user_id=user_register.id')
                      ->join('student_profile','student_profile.user_id=user_register.id','left')
                      ->where('user_role.role',2)
                      ->order_by("user_register.id", "desc")
                      ->get();
              return $Data->result();        

    }

    //=========== Get All Registered Experts Data Function 24-07-19 ===========//
    public function getAllExperts(){
    	$sqlData = $this->db->select('*')
                          ->from('experts_register')
                          ->order_by("id", "desc")
                          ->get();
                  return $sqlData->result();
    }


  //============ Student Deleted Function START::24-07-19 =============//
    public function deleteStudentRecords($id){
      $data = $this->db->where('id',$id)
                      ->delete('user_register');
                  return true;    
    }

//============ Expert Deleted Function START::25-07-19 =============//
    public function deleteExpertRecords($exprtid){
      $data = $this->db->where('id',$exprtid)
                      ->delete('experts_register');
                  return true;    
    }

    

}