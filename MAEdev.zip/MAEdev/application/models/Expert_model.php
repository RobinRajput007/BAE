<?php 
if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Expert_model extends CI_Model
{
	 function __construct(){ 
        parent::__construct(); 
        $this->load->database(); 
        date_default_timezone_set("Asia/Calcutta");
    }

    //============= Check Expert Exist or Not ============//
    public function getExpert($email){
       
       $data = $this->db->select('*')
                        ->from('experts_register')
                        ->where('email',$email)
                        ->get();

                   return $data->num_rows();     
    }

    //=============== Expert Register Function START::22-07-19 ===========//
    public function registerExperts($data){
    	$data = $this->db->insert('experts_register',$data);
    	return true;
    }

    //========= Expert Login Function Start :: on date 22-07-19 by robin ==========//

    public function expertLogin($email,$password){
      $condition = array('email'=>$email,'password'=>md5($password));      
      $data = $this->db->select('id,full_name,phone_no,email')
                        ->from('experts_register')                       
                        ->where($condition)
                        ->get();
                 return $data->result();       
    }

    //=============== Check Email id exist or not with us Fun. START::23-07-19 ================//
    public function getMailid($email){
    	$data = $this->db->select('id,email,full_name,phone_no')
    	                 ->from('experts_register')
    	                 ->where('email',$email)
    	                 ->get();
    	           return $data->result();      
    }
}