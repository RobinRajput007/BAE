<?php 
if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Student_model extends CI_Model
{
	 function __construct(){ 
        parent::__construct(); 
        $this->load->database(); 
        date_default_timezone_set("Asia/Calcutta");
    }


    //=========== Get Register Student Row Function ============//
    public function getRegisterStudentRow($email){
     $rowData = $this->db->select('*')
                      ->from('user_register')
                      ->where('email',$email)
                      ->get();
              return $rowData->num_rows();        

    }

    //=========== Insert Student Register Data Function ===========//
    public function studentInsertData($insertData){
    	$sqlData = $this->db->insert('user_register',$insertData);

      $insert_id = $this->db->insert_id();        
    	  return $insert_id;
    }


  //============ User Role Permission Table Insert Data =============//
    public function insertRoleData($lastId){
      $roleArr = array(
               'user_id'=>$lastId,
               'role'=>2,
               'created_at'=>date('Y-m-d h:i:s')
           );
      $this->db->insert('user_role',$roleArr);
    }


    //========= User Login Function Start :: on date 16-07-19 by robin ==========//

    public function userLogin($email,$password){
      $condition = array('email'=>$email,'password'=>md5($password));
      //print_r($condition);die;
      $data = $this->db->select('user_register.*,user_role.user_id,user_role.role,user_role.permission')
                        ->from('user_register')
                        ->join('user_role', 'user_role.user_id = user_register.id')
                        ->where($condition)
                        ->get();

                 return $data->result();       
    }

    //=============== student profile function start::on 20-07-19 by robin ================//
    public function insertProfileData($lastId){
           
            $profileData = array(
               'user_id'=>$lastId,               
               'created_at'=>date('Y-m-d h:i:s')
               );
              $this->db->insert('student_profile',$profileData);

            return true; 
    }

  //================ Update Student Profile Data function Start::on 20-07-19 ================//
  public function updateStudentProfile($data,$id){
                $this->db->where('user_id',$id);
                $this->db->update('student_profile',$data);
                return true;
  } 

 //============= get student profile for images ============//
  public function getStudentProfile($userId){
       
       $data = $this->db->select('id,user_id,profile_pic')
                       ->from('student_profile')
                       ->where('user_id',$userId)
                       ->get();
                  return $data->result();     
  }

  //================ Student Get Save Profile Function ===================//
  public function getStudentProfileData($userId){
     $data = $this->db->select('*')
                      ->from('student_profile')
                      ->where('user_id',$userId)
                      ->get();

                 return $data->result();     
  }

}