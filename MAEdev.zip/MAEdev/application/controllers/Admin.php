<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {

	public function _construct()
	{
	    parent::__construct();
	    $this->load->database(); 	   
	    $this->load->helper('cookie'); /* load cookie default form helper */
      date_default_timezone_set("Asia/Calcutta");
	}

	//============== Admin Dashboard Function Start::19-07-19 =================//
  public function adminDashboard(){
          $loginUser = $this->session->userdata('userData'); // admin session data 
           //echo '<pre>';print_r($loginUser);die;
          if(!empty($loginUser)){
          	$studentData = $this->Admin_model->getAllStudents();
          	$expertData = $this->Admin_model->getAllExperts();
          	$this->load->view('admin/dashboard',compact('studentData','expertData'));
          }else{

          	return redirect('/');
          }  
  }

 //=============== Show All Students List Function START::24-07-19===============//
 public function allStudents(){

 	$studentData = $this->Admin_model->getAllStudents();
 	//echo '<pre>';print_r($studentData);die;
 	$this->load->view('admin/all_students',compact('studentData'));

 }

//=============== Show All Experts List Function START::24-07-19===============//
 public function allExperts(){
    $expertData = $this->Admin_model->getAllExperts();
 	//echo '<pre>';print_r($expertData);die;
 	$this->load->view('admin/all_experts',compact('expertData'));

 }

 //=================== Admin LogOut Function START::24-07-19=================//
 public function logOut(){

 	 $loggedIn = $this->session->userdata('userData');

  	if(!empty($loginUser)){
  		$this->session->sess_destroy('userData');
  		return redirect('/'); 
  	}else{
  		return redirect('/'); 
  	}
 }

 //============== All Admin Assignments Function START::24-07-19===============//
 public function adminAllAssignments(){
 	$this->load->view('admin/all_assignments');
 }

 //============ Student Deleted Function START::24-07-19===========//
 public function studentDeleted(){
 	 if($this->input->is_ajax_request()){
 	  $studentId = $this->input->post('studentid'); 	  
	     if(!empty($studentId)){           
           $deleteResponse = $this->Admin_model->deleteStudentRecords($studentId);
          if(isset($deleteResponse)){
          	echo 'success';die;
          }else{
            echo 'db_error';die;
          }

	     }else{
	     	echo 'id_error';die;
	     }
 	 }else{
 	 	echo 'ajax_error';die;
 	 }
 }

 //============ Experts Deleted Function START::25-07-19===========//
 public function expertDeleted(){
 	 if($this->input->is_ajax_request()){
 	   $expertId = $this->input->post('exprtid'); 	  
	     if(!empty($expertId)){           
           $deleteResponse = $this->Admin_model->deleteExpertRecords($expertId);
          if(isset($deleteResponse)){
          	echo 'success';die;
          }else{
            echo 'db_error';die;
          }

	     }else{
	     	echo 'id_error';die;
	     }
 	 }else{
 	 	echo 'ajax_error';die;
 	 }
 }


}