<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Expert extends CI_Controller {

    public function _construct()
	{
	    parent::__construct();
	    $this->load->database(); 	    
	    $this->load->helper('cookie'); /* load cookie default form helper */
        date_default_timezone_set("Asia/Calcutta");
	}


	public function index()
	{
		$this->load->view('experts/login');
	}

	//=============== Expert Register View Function Start::22-07-19============//
	public function expertRegisterView(){
        
        //========= call time slot fun.========//
        $startTime = '12:00 AM';
        $endTime = '12:00 PM';
        $duration = '30';

        $timeSlots = $this->SplitTime($startTime,$endTime,$duration);
       
		$this->load->view('experts/register',compact('timeSlots'));
	}

	//=========== Make Time Slots Function START::22-07-19 ===============//
	function SplitTime($StartTime, $EndTime, $Duration="60"){
    $ReturnArray = array ();// Define output
    $StartTime    = strtotime ($StartTime); //Get Timestamp
    $EndTime      = strtotime ($EndTime); //Get Timestamp

    $AddMins  = $Duration * 60;

    while ($StartTime <= $EndTime) //Run loop
    {
        $ReturnArray[] = date ("h:i A", $StartTime); //date ("G:i", $StartTime);
        $StartTime += $AddMins; //Endtime check
    }
    return $ReturnArray;
   }

   //================== Expert Register Function START:: 22-07-19 ==============//
   public  function expertRegister(){
      $data = $this->input->post();     
      $timeAvailable = array();
      if(isset($data['availability'])){
      	 if(isset($data['availability'][1])){
      	 	$hours = $data['availability'][1];
      	 }else{
      	 	$hours = null;
      	 }
      	 $timeAvailableArr = array('days'=>$data['availability'][0],'hours'=>$hours);

      	 $timeAvailable = json_encode($timeAvailableArr);
      }
   
      $insertData = array(
                     'full_name'=>htmlentities(trim($data['fullname'])),
                     'phone_no'=>htmlentities(trim($data['phone'])),
                     'email'=>htmlentities(trim($data['email'])),
                     'password'=>htmlentities(trim(md5($data['Password']))),
                     'qualification'=>htmlentities(trim($data['qualification'])),
                     'area_of_expertise'=>htmlentities(trim($data['expertise'])),
                     'availability'=>$timeAvailable,
                     'address'=>htmlentities(trim($data['address'])),
                     'working_hours'=>htmlentities(trim($data['available_time'])),
                     'expeted_cost_perpage'=>htmlentities(trim($data['cost_per_page'])),
                     'agree_terms'=>htmlentities(trim($data['agree_term'])),
                     'created_at' =>date('Y-m-d h:i:s'),
                   );

	      $existUserCount = $this->Expert_model->getExpert($data['email']);
	      
	      if($existUserCount<1){
             $expertData = $this->Expert_model->registerExperts($insertData);
		   	  if(isset($expertData)){		   	  	   
		   	  	   $this->session->set_flashdata('msg','success');
		   	  	   return redirect('expert_register_view');
			   	  }else{
			   	  	echo 'error';
			   	  	$this->session->set_flashdata('msg','dberror');
			   	  	return redirect('expert_register_view');
			   	  }
	      }else{
             $this->session->set_flashdata('msg','exist');
             return redirect('expert_register_view');
	      }	   	  
   	  
   }

  //========== Expert Login Function START:: on 22-07-19 ==========//

	public function expertLogin(){

	 if($this->input->is_ajax_request()){
		   $this->form_validation->set_rules('email', 'Email ID', 'required|valid_email');
	     $this->form_validation->set_rules('password', 'Password', 'required');

	     $loginArr = array();

        if($this->form_validation->run()==true)
	     {
	    	  $emailID = htmlentities(trim($this->input->post('email')));
			  $password = htmlentities(trim($this->input->post('password')));
			  $remember = htmlentities((int) $this->input->post('remember'));
           
			  $loginData = $this->Expert_model->expertLogin($emailID, $password);
             //echo '<pre>';print_r($loginData);die;
			
			 if($loginData){
			 	  $this->session->set_userdata('expertData',$loginData);
                if($remember==1){
                $this->input->set_cookie('Eemail', $emailID, 86500); /* Create cookie for store emailid */
                $this->input->set_cookie('Epassword', $password, 86500); /* Create cookie for password */
                        	
                 $loginArr['status'] = '200';
                 $loginArr['statusText'] = 'loginWithRemember';
                 $loginArr['loginData'] = $loginData[0];

                 echo json_encode($loginArr);die;

                }else{                       
                     delete_cookie('Eemail'); /* Delete Expert email cookie */
                     delete_cookie('Epassword'); /* Delete Expert password cookie */
                     $loginArr['status'] = '200';
                     $loginArr['statusText'] = 'loginWithOutRemember';
                     $loginArr['loginData'] = $loginData[0];
                     echo json_encode($loginArr);die;
                }
			 }else{

			 	   $loginArr['status'] = '204';//No Content status error
                   $loginArr['statusText'] = 'invalid_error';
                  $loginArr['loginData'] = 'Please Enter Valid Username and Password';
                  echo json_encode($loginArr);die;
			 }

	    }else{          
                $loginArr['status'] = '403';//Forbidden server status
                $loginArr['statusText'] = 'validation_error';
                $loginArr['loginData'] = 'Please Enter  Username and Password';
                echo json_encode($loginArr);die;
	    }
	 }else{
	 	   
	 	     $loginArr['status'] = '401';//Unauthorized server status error
             $loginArr['statusText'] = 'unauthorized';
             $loginArr['loginData'] = 'No direct script access allowed';
             echo json_encode($loginArr);die;
	 }

  }

  //================ Expert Dashboard Function START:: 22-07-19 ================//
  public function expertDashboard(){
    $loggedInData =  $this->session->userdata('expertData');

    echo '<pre>';print_r($loggedInData);die;
     echo 'Expert Logged in Successfully.';
  }

  //========== Forgot Password Function START::22-07-19 =============//
  public function forgotPassword(){

  	$this->load->view('experts/forgot_password');
  }

  //=================== Send Forgot Mail Function START::23-07-19 ==============//
  public function sendForgotMail(){
      
      $email = htmlentities(trim($this->input->post('email')));
      $chkMail = $this->Expert_model->getMailid($email);
      //$this->load->helper('forgotmail');

      if(!empty($chkMail)){        
        $mailTemplate = 'mailer/forgotpass_mail';
        $mailData['name'] = $chkMail[0]->full_name;
        $mailData['email'] = $chkMail[0]->email;
        $mailData['phone'] = $chkMail[0]->phone_no; 
        $mailTo = 'robin.inasoft@gmail.com';
        $mailFrom = $chkMail[0]->email;

        $mailObj = $this->forgotMail($mailFrom,$mailTo,$mailData,$mailTemplate); // function defined in helper 
        if($mailObj=='success'){
              echo 'mail_success';die;
        }else{
           echo 'mail_send_err';die;
        }      
      }else{

      	  echo 'user_register_err';die;
      }
      
     
  }

//============== Send Forgot Mail Function =================//
  function forgotMail($from,$to,$mailData,$mailTemplate){

      $config = Array(
					'protocol' => 'smtp',							
					'smtp_host' => 'ssl://smtp.gmail.com',
					'smtp_port' => 465,							
					'smtp_user' =>'donotreply@wealthveda.com',							
					'smtp_pass' => 'rijkdom@125',
					'mailtype'  => 'html', 
					'charset'   => 'iso-8859-1'
				);

		$this->load->library('email',$config);		
        //$body = $this->load->view('mailer/itinerary_enabled_mail',$data, true); 
        $body = $this->load->view($mailTemplate,$mailData, true);                               
		$this->email->set_newline("\r\n");
		$this->email->from($from, 'Best Assignment Experts');
		$this->email->to($to);		
		$this->email->subject('Forgot Password Link');
		$this->email->message($body);
	   $msg =  $this->email->send(); 
	   if($msg){

	   	  echo 'success';die;
	   }else{

	   	 echo 'mail_error';die;
	   }     

}


}
