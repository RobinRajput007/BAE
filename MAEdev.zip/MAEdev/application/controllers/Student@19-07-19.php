<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Student extends CI_Controller {

	public function _construct()
	{
	    parent::__construct();
	    $this->load->database(); 	  
	    $this->load->model('Student_model');
	    $this->load->helper('cookie'); /* load cookie default form helper */
	}

	public function index()
	{
		$this->load->view('students/index');
	}

    
	//======== Student Register function Start============//
	public function studentRegister(){
	   $data = $this->input->post();
	   
	   if(!empty(array_filter($data))){	

	    /*$user_ip = $this->input->ip_address();	   
	    $geopluginURL='http://www.geoplugin.net/php.gp?ip='.$user_ip;
        $addrDetailsArr = unserialize(file_get_contents($geopluginURL));      
        echo '<pre>';print_r($addrDetailsArr) ;die;*/

        
	   	   $insert = array(
                  'name'=>trim($this->input->post('name')),
                  'email'=>trim($this->input->post('email')),
                  'password'=>trim(md5($this->input->post('password'))),
                  'country_code'=>trim($this->input->post('country_code')),
                  'phone'=>trim($this->input->post('phone')),
                  'i_agree'=>trim($this->input->post('i_agree')),
                  'created_at'=>date('Y-m-d h:i:s'),
                  'updated_at'=>NULL
	   	     );	
      
         $chkRegister = $this->Student_model->getRegisterStudentRow($insert['email']);
         //echo $chkRegister;die;
         if($chkRegister<1){
         	$registerData = $this->Student_model->studentInsertData($insert);
		   	 if($registerData){
		   	 	 $msg = 'insert value successful.';
		   	 	 $this->session->set_flashdata('registerMsg', $msg);
		   	 }else{
		   	 	 $msg = 'Database Error';
		   	 	 $this->session->set_flashdata('registerMsg', $msg);
		   	 }
		   	}else{
		   		 $msg = 'Student Already Register';
		   		 $this->session->set_flashdata('registerMsg', $msg);
		   	}

	   	  $this->load->view('students/student_register');
	   }else{
	   	$this->load->view('students/student_register');
	   }	
		
	}


	//========== Student Login Function START:: on 12-07-19 ==========//

	public function studentLogin(){

	 if($this->input->is_ajax_request()){
		 $this->form_validation->set_rules('userEmail', 'Email ID', 'required|valid_email');
	     $this->form_validation->set_rules('userPassword', 'Password', 'required');

	     $loginArr = array();

        if($this->form_validation->run()==true)
	     {
	    	$emailID = htmlentities(trim($this->input->post('userEmail')));
			$password = htmlentities(trim($this->input->post('userPassword')));
			$remember = htmlentities((int) $this->input->post('remember'));
           
			$loginData = $this->Student_model->userLogin($emailID, $password);
			
			 if($loginData){

			 	$this->session->set_userdata('studentData',$loginData);

                if($remember==1){

                $this->input->set_cookie('semail', $emailID, 86500); /* Create cookie for store emailid */
                $this->input->set_cookie('spassword', $password, 86500); /* Create cookie for password */
                        	
                 $loginArr['status'] = '200';
                 $loginArr['statusText'] = 'loginWithRemember';
                 $loginArr['loginData'] = $loginData[0];

                 echo json_encode($loginArr);die;

                }else{                       
                     delete_cookie('semail'); /* Delete student email cookie */
                     delete_cookie('spassword'); /* Delete student password cookie */
                     $loginArr['status'] = '200';
                     $loginArr['statusText'] = 'loginWithOutRemember';
                     $loginArr['loginData'] = $loginData[0];
                     echo json_encode($loginArr);die;
                }
			 }else{

			 	 $loginArr['status'] = '204';//No Content status error
                 $loginArr['statusText'] = 'invalid_error';
                 $loginArr['loginData'] = 'Please Enter Valid Username and Password';
                 echo json_encode($loginArr);die;
			 }

	    }else{          
                $loginArr['status'] = '403';//Forbidden server status
                $loginArr['statusText'] = 'validation_error';
                $loginArr['loginData'] = 'Please Enter  Username and Password';
                echo json_encode($loginArr);die;
	    }
	 }else{
	 	   
	 	    $loginArr['status'] = '401';//Unauthorized server status error
            $loginArr['statusText'] = 'unauthorized';
            $loginArr['loginData'] = 'No direct script access allowed';
            echo json_encode($loginArr);die;
	 }

  }


  //=============== Logout Function Start:: 16-07-19 by robin ==============//

  public function logOut(){

  	$loginUser = $this->session->userdata('studentData');

  	if(!empty($loginUser)){
  		$this->session->sess_destroy('studentData');
  		return redirect('/'); 
  	}else{
  		return redirect('/'); 
  	}
  }

  //============== Student Dashboard Function Start :: 16-07-19 by robin ===============//
  public function studentDashboard(){
    $loginUser = $this->session->userdata('studentData'); // student session data 
    $this->load->view('students/student_dashboard');
  }


  //================ Student Forgot Password Function Start:: 16-07-19 by robin=============//

  public function studentForgotPass(){
  	$this->load->view('students/forgot_password');
  }


  //================ Student Forgot Password Function Start:: 17-07-19 by robin ============//
  public function forgotPasswordMail(){
  	
  }

}
