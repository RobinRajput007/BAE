<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller {

	public function _construct()
	{
	    parent::__construct();
	    $this->load->database(); 	  
	    $this->load->model('User_model');
	    $this->load->helper('cookie'); /* load cookie default form helper */
      date_default_timezone_set("Asia/Calcutta");
	}

	public function index()
	{
		$this->load->view('students/index');
	}

    
	//======== Student Register function Start============//
	public function studentRegister(){
	   $data = $this->input->post();
	   
	   if(!empty(array_filter($data))){	

	    /*$user_ip = $this->input->ip_address();	   
	    $geopluginURL='http://www.geoplugin.net/php.gp?ip='.$user_ip;
        $addrDetailsArr = unserialize(file_get_contents($geopluginURL));      
        echo '<pre>';print_r($addrDetailsArr) ;die;*/
        $ip = $this->get_client_ip();
       // echo '<pre>';print_r($ip) ;die;

	   	   $insert = array(
                  'name'=>trim($this->input->post('name')),
                  'email'=>trim($this->input->post('email')),
                  'password'=>trim(md5($this->input->post('password'))),
                  'country_code'=>trim($this->input->post('country_code')),
                  'phone'=>trim($this->input->post('phone')),
                  'i_agree'=>trim($this->input->post('i_agree')),
                  'created_at'=>date('Y-m-d h:i:s'),
                  'updated_at'=>NULL
	   	     );	
      
         $chkRegister = $this->User_model->getRegisterStudentRow($insert['email']);
         
         if($chkRegister<1){
         	$registerData = $this->User_model->studentInsertData($insert);

		   	 if($registerData){           
           $userRoleData = $this->User_model->insertRoleData($registerData); // data insert to role, permission into user_role table
           $studentProfile = $this->User_model->insertProfileData($registerData); // data insert to student_profile db table
		   	 	 $msg = 'insert value successful.';
		   	 	 $this->session->set_flashdata('registerMsg', $msg);
		   	 }else{
		   	 	 $msg = 'Database Error';
		   	 	 $this->session->set_flashdata('registerMsg', $msg);
		   	 }
		   	}else{
		   		 $msg = 'Student Already Register';
		   		 $this->session->set_flashdata('registerMsg', $msg);
		   	}

	   	  $this->load->view('students/student_register');
	   }else{
	   	$this->load->view('students/student_register');
	   }	
		
	}


	//========== User Login Function START:: on 12-07-19 ==========//

	public function userLogin(){

	 if($this->input->is_ajax_request()){
		   $this->form_validation->set_rules('userEmail', 'Email ID', 'required|valid_email');
	     $this->form_validation->set_rules('userPassword', 'Password', 'required');

	     $loginArr = array();

        if($this->form_validation->run()==true)
	     {
	    	$emailID = htmlentities(trim($this->input->post('userEmail')));
			  $password = htmlentities(trim($this->input->post('userPassword')));
			  $remember = htmlentities((int) $this->input->post('remember'));
           
			  $loginData = $this->User_model->userLogin($emailID, $password);

        //echo '<pre>';print_r($loginData);die;
			
			 if($loginData){

			 	    $this->session->set_userdata('userData',$loginData);

                if($remember==1){

                $this->input->set_cookie('semail', $emailID, 86500); /* Create cookie for store emailid */
                $this->input->set_cookie('spassword', $password, 86500); /* Create cookie for password */
                        	
                 $loginArr['status'] = '200';
                 $loginArr['statusText'] = 'loginWithRemember';
                 $loginArr['loginData'] = $loginData[0];

                 echo json_encode($loginArr);die;

                }else{                       
                     delete_cookie('semail'); /* Delete student email cookie */
                     delete_cookie('spassword'); /* Delete student password cookie */
                     $loginArr['status'] = '200';
                     $loginArr['statusText'] = 'loginWithOutRemember';
                     $loginArr['loginData'] = $loginData[0];
                     echo json_encode($loginArr);die;
                }
			 }else{

			 	         $loginArr['status'] = '204';//No Content status error
                 $loginArr['statusText'] = 'invalid_error';
                 $loginArr['loginData'] = 'Please Enter Valid Username and Password';
                 echo json_encode($loginArr);die;
			 }

	    }else{          
                $loginArr['status'] = '403';//Forbidden server status
                $loginArr['statusText'] = 'validation_error';
                $loginArr['loginData'] = 'Please Enter  Username and Password';
                echo json_encode($loginArr);die;
	    }
	 }else{
	 	   
	 	        $loginArr['status'] = '401';//Unauthorized server status error
            $loginArr['statusText'] = 'unauthorized';
            $loginArr['loginData'] = 'No direct script access allowed';
            echo json_encode($loginArr);die;
	 }

  }


  //=============== Logout Function Start:: 16-07-19 by robin ==============//

  public function logOut(){

  	$loginUser = $this->session->userdata('userData');

  	if(!empty($loginUser)){
  		$this->session->sess_destroy('userData');
  		return redirect('/'); 
  	}else{
  		return redirect('/'); 
  	}
  }

  //============== Student Dashboard Function Start :: 16-07-19 by robin ===============//
  public function studentDashboard(){
    $loginUser = $this->session->userdata('userData'); // student session data 
    
    if(!empty($loginUser)){
      $profileSet = $this->User_model->getStudentProfileData($loginUser[0]->user_id);
      if(!empty($profileSet)){
        $profileData = $profileSet[0];
      }
      
      $this->load->view('students/student_dashboard',compact('profileData'));
    }else{
       return redirect('/');
    }
    
  }


  //================ Student Forgot Password Function Start:: 16-07-19 by robin=============//

  public function studentForgotPass(){
  	$this->load->view('students/forgot_password');
  }


  //================ Student Forgot Password Function Start:: 17-07-19 by robin ============//
  public function forgotPasswordMail(){
  	
  }

  //============== Admin Dashboard Function Start::19-07-19 =================//
  /*public function adminDashboard(){
          $loginUser = $this->session->userdata('userData'); // admin session data 
          //echo '<pre>';print_r($loginUser);die;
           echo 'admin loggin success';die;
  }*/


  // Function to get the client IP address
function get_client_ip() {
    $ipaddress = '';
    if (isset($_SERVER['HTTP_CLIENT_IP']))
        $ipaddress = $_SERVER['HTTP_CLIENT_IP'];
    else if(isset($_SERVER['HTTP_X_FORWARDED_FOR']))
        $ipaddress = $_SERVER['HTTP_X_FORWARDED_FOR'];
    else if(isset($_SERVER['HTTP_X_FORWARDED']))
        $ipaddress = $_SERVER['HTTP_X_FORWARDED'];
    else if(isset($_SERVER['HTTP_FORWARDED_FOR']))
        $ipaddress = $_SERVER['HTTP_FORWARDED_FOR'];
    else if(isset($_SERVER['HTTP_FORWARDED']))
        $ipaddress = $_SERVER['HTTP_FORWARDED'];
    else if(isset($_SERVER['REMOTE_ADDR']))
        $ipaddress = $_SERVER['REMOTE_ADDR'];
    else
        $ipaddress = 'UNKNOWN';
    return $ipaddress;
}

//============= Student Profile View Function =================//
public function studentProfileView(){
  $loginUser = $this->session->userdata('userData'); // student session data  
  if(!empty($loginUser)){ 
    $profileSet = $this->User_model->getStudentProfileData($loginUser[0]->user_id);
    if(!empty($profileSet)){
      $profileData = $profileSet[0]; 
    }
    
    $this->load->view('students/student_profile',compact('loginUser','profileData'));
    }else{
       return redirect('/');
    }
}

//================== Student Profile Function Start::on 20-07-19 ================//
public function studentProfile(){

   $loginUser = $this->session->userdata('userData'); // student session data
   $profileData = $this->input->post();
   $profilePic = $_FILES['profile_pic'];
   
   if(!empty(array_filter($profileData))) {

     //============ file name and extention =============//
       $uniueId = uniqid(); 
       $ext = pathinfo($profilePic['name'], PATHINFO_EXTENSION);   
       $fileName = pathinfo($profilePic['name'], PATHINFO_FILENAME);  
      
       $file_name = $fileName.'_'.$uniueId.'.'.$ext;
       
     $studentImage = $this->do_upload($profilePic,$loginUser,$file_name);// function for student pic. upload
     
     $fileLocation = base_url().'uploads/student_pic/'.$studentImage;

     $updateData = array(
                'address'=>$profileData['address'],
                'about_me'=>$profileData['about_me'],
                'qualification'=>$profileData['qualification'],
                'profile_pic' =>$studentImage,
                'image_url' => $fileLocation,
                'created_at'=>date('Y-m-d h:i:s')
               );
           
             $this->User_model->updateStudentProfile($updateData,$loginUser[0]->id); 
             return redirect('student_profile');
     }else{
         return redirect('student_profile');
        //$dataMsg = '';
        //$this->load->view('students/student_profile',compact('dataMsg','loginUser'));
   }
   
 }


 //=================== Upload Student Profile Pic Function Start::on 20-07-19================//
 public function do_upload($file,$loginUser,$fileName)
               {
                
               if($file['name']!="" && !empty($file))
                { 
                  $config = array(
                      'upload_path' => "./uploads/student_pic/",
                      'allowed_types' => "gif|jpg|png|jpeg",
                      'overwrite' => TRUE,
                      'max_size' => "2048000", // Can be set to particular file size , here it is 2 MB(2048 Kb)
                      //'max_height' => "768",
                      //'max_width' => "1024"
                      'file_name' =>$fileName
                      );

                 $this->load->library('upload');                
                 $this->upload->initialize($config); 
                 
                if (!$this->upload->do_upload('profile_pic'))
                {
                        $error = array('error' => $this->upload->display_errors()); 
                        //echo '<pre>';print_r($error);die;                      
                        $this->session->set_flashdata('error',$error);
                       // $this->load->view('students/student_profile', $error);
                }
                else
                {
                   $fileData = $this->upload->data(); 
                  // echo '<pre>';print_r($fileData);die; 
                  //$fileData['file_name'] = $fileName; // it's use for unique id added in image name.
                  
                   //================ remove exist image from folder =============//
                   $imagedata = $this->User_model->getStudentProfile($loginUser[0]->user_id);
                   //echo '<pre>';print_r($imagedata);die;
                   $fileLocation =  base_url().'uploads/student_pic/'.$imagedata[0]->profile_pic; 
                   //echo $fileLocation;die;                 
                     if (file_exists($imagedata[0]->profile_pic)) {
                        unlink($fileLocation);
                      }

                   $config['image_library'] ='gd2';
                   $config['source_image']  ='./uploads/student_pic/'.$fileName;
                   $config['create_thumb']  = FALSE;
                   $config['maintain_ratio']= FALSE;
                   $config['new_image']     = './uploads/student_pic/'.$fileName;
                   $this->load->library('image_lib', $config); 
                   $this->upload->initialize($config);                  
                    return $fileData['file_name'];
                        
                }
              }else{

                 return $this->input->post('profile_pic_old');
              }
        }



}
