<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Student extends CI_Controller {

	public function _construct()
	{
	    parent::__construct();
	    $this->load->database(); 	   
	    $this->load->helper('cookie'); /* load cookie default form helper */
      date_default_timezone_set("Asia/Calcutta");
	}

	//=========== Show all assignments function START:: 23-07-19=============//
	public function allAssignments()
	{
		$loginUser = $this->session->userdata('userData'); // student session data 
		
		if(!empty($loginUser)){
		   $profileSet = $this->User_model->getStudentProfileData($loginUser[0]->user_id);
		   if(!empty($profileSet)){
		   	$profileData = $profileSet[0];
		   }
           
		   $this->load->view('students/all_assignments',compact('profileData'));
		}else{
			return redirect('/');
		}  
        
	}

}