<?php 

   function forgotMail($from,$to,$mailData,$mailTemplate){

      $config = Array(
					'protocol' => 'smtp',							
					'smtp_host' => 'ssl://smtp.gmail.com',
					'smtp_port' => 465,							
					'smtp_user' =>'donotreply@wealthveda.com',							
					'smtp_pass' => 'rijkdom@125',
					'mailtype'  => 'html', 
					'charset'   => 'iso-8859-1'
				);	


		$this->load->library('email',$config);
		echo 'success';	die;
        //$body = $this->load->view('mailer/itinerary_enabled_mail',$data, true); 
        $body = $this->load->view($mailTemplate,$mailData, true);                       
		$this->email->set_newline("\r\n");
		$this->email->from($from, 'Best Assignment Experts');
		$this->email->to($to);		
		$this->email->subject('Forgot Password Link');
		$this->email->message($body);
	   $msg =  $this->email->send(); 
	   if($msg){

	   	  echo 'success';die;
	   }else{

	   	 echo 'mail_error';die;
	   }     

}