<?php

$config = [
	       "user_profile_rule" =>[
	       	                       [
	       	                       	'field'=>'first_name',
	       	                       	'lable'=>'First Name',
	       	                       	'rules'=>'required'
	       	                       ],
	       	                       [
	       	                       	"field"=>'last_name',
	       	                       	"lable"=>'Last Name',
	       	                       	"rules"=>'required'
	       	                       ],
	       	                       
	       	                       [
	       	                       	"field"=>'email_id',
	       	                       	"lable"=>'Email Id',
	       	                       	"rules"=>'required|valid_email'
	       	                       ],
	       	                    
	       	                        [
	       	                       	"field"=>'gender',
	       	                       	"lable"=>'Gender',
	       	                       	"rules"=>'required'
	       	                       ],
	       	                       [
	       	                       	"field"=>'nationality',
	       	                       	"lable"=>'Nationality',
	       	                       	"rules"=>'required'
	       	                       ],
	       	                       [
	       	                       	"field"=>'date_of_birth',
	       	                       	"lable"=>'Date Of Birth',
	       	                       	"rules"=>'required'
	       	                       ],
	       	                       [
	       	                       	"field"=>'description',
	       	                       	"lable"=>'Discription',
	       	                       	"rules"=>'required|max_length[200]'
	       	                       ],
	       	                       [
	       	                       	"field"=>'per_address_1',
	       	                       	"lable"=>'Permanent Address 1',
	       	                       	"rules"=>'required'
	       	                       ],
	       	                       [
	       	                       	"field"=>'per_address_2',
	       	                       	"lable"=>'Permanent Address 2',
	       	                       	"rules"=>'required'
	       	                       ],
	       	                      
	       	                        [
	       	                       	"field"=>'state',
	       	                       	"lable"=>'State',
	       	                       	"rules"=>'required'
	       	                       ],
	       	                        [
	       	                       	"field"=>'city',
	       	                       	"lable"=>'City',
	       	                       	"rules"=>'required'
	       	                       ],
	       	                      
	       	                       [
	       	                       	"field"=>'interest[]',
	       	                       	"lable"=>'Intereset ',
	       	                       	"rules"=>'required'
	       	                       ],
	       	                       [
	       	                       	"field"=>'services_offered[]',
	       	                       	"lable"=>'Services Offered ',
	       	                       	"rules"=>'required'
	       	                       ],
	       	                       [
	       	                       	"field"=>'preferred_cities[]',
	       	                       	"lable"=>'Preferred Cities ',
	       	                       	"rules"=>'required'
	       	                       ],
	       	                       
	       	                       [
	       	                       	"field"=>'preferred_languages',
	       	                       	"lable"=>'preferred_languages ',
	       	                       	"rules"=>'required'
	       	                       ],
	       	                       [
	       	                       	"field"=>'host_before',
	       	                       	"lable"=>'Host Before',
	       	                       	"rules"=>'required'
	       	                       ],
	       	                       [
	       	                       	"field"=>'adhaar_number',
	       	                       	"lable"=>'Adhaar Number',
	       	                       	"rules"=>'required'
	       	                       ],
	       	                      
	       	                       [
	       	                       	"field"=>'pan_number',
	       	                       	"lable"=>'Pan Number',
	       	                       	"rules"=>'required'
	       	                       ]
	       	                       
	                             ]
	                         ]
          
?>