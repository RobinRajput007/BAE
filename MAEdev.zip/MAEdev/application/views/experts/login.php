<?php require_once('header.php');?>
<body id="top" class="bg-color-8">
<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-TAGCODE"
                  height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->
<div class="page_loader"></div>

<!-- Login 8 start -->
<div class="login-8">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="login-inner-form">
                    <div class="logo-2">
                        <a href="#">
                            <img src="<?php echo base_url();?>expertassets/img/logo.png" alt="logo">
                        </a>
                    </div>

                    <div class="details">
                         <div id="alertMsg"></div>
                        <h3>Sign into your account</h3>
                        <form id="formData" method="post">
                            <div class="form-group form-box">
                                <input type="email" name="email" class="input-text" placeholder="Email Address" 
                                value="<?php if (get_cookie('Eemail')) { echo get_cookie('Eemail'); } ?>" required>
                                <i class="flaticon-mail-2"></i>
                            </div>
                            <div class="form-group form-box">
                                <input type="password" name="password" class="input-text" placeholder="Password" 
                                value="<?php if (get_cookie('Epassword')) { echo get_cookie('Epassword'); } ?>" required>
                                <i class="flaticon-password"></i>
                            </div>
                            <div class="checkbox clearfix">
                                <div class="form-check checkbox-theme">
                                    <input class="form-check-input" type="checkbox" name="remember" id="remember" value="1" 
                                    <?php if (get_cookie('Eemail')) { ?> checked="checked" <?php } ?> />
                                    <label class="form-check-label" for="remember">
                                        Remember me
                                    </label>
                                   
                                </div>
                                <a href="<?php echo base_url();?>expert_forgot_pass">Forgot Password</a>
                            </div>
                            <div class="form-group mb-0">
                                <button type="button" id="expertLogin" class="btn-md btn-theme btn-block">Login</button>
                            </div>
                            <div class="extra-login">
                                <span>Or Login With</span>
                            </div>
                            <ul class="social-list clearfix">
                                <li><a href="#" class="facebook-bg">Facebook</a></li>
                                <li><a href="#" class="twitter-bg">Twitter</a></li>
                                <li><a href="#" class="google-bg">Google</a></li>
                            </ul>
                        </form>
                    </div>
                    <p>Don't have an account? <a href="<?php echo base_url();?>expert_register_view" class="thembo"> Register here</a></p>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
<?php require_once('footer.php');?>

<script type="text/javascript">
  $(document).ready(function(){
   $('#expertLogin').on('click',function(){
      var formData = $('#formData').serialize();
      var proceed = true;

      if(proceed){

         $.ajax({
               type:'post',
               url:'<?php echo base_url()?>expert_login', //route url
               data:formData,
               dataType:'json',
               success:function(response){
                console.log(response.loginData);
                if($.trim(response.status==200) && $.trim(response.statusText)=='loginWithRemember'){
                   window.location.href= '<?php echo base_url()?>expert_dashboard';                  
                }
                else if($.trim(response.status==200) && $.trim(response.statusText)=='loginWithOutRemember'){
                  window.location.href= '<?php echo base_url()?>expert_dashboard';                   
                }

               else if($.trim(response.status==204) && $.trim(response.statusText)=='invalid_error'){                   
                    $('#alertMsg').html('<div class="alert alert-warning alert-dismissible fade show" role="alert"><strong>Oops! </strong>'+response.loginData+'<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>');
                }
               else if($.trim(response.status==401) && $.trim(response.statusText)=='unauthorized'){
                    $('#alertMsg').html('<div class="alert alert-warning alert-dismissible fade show" role="alert"><strong>Oops! </strong>'+response.loginData+'<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>');
                }
               else if($.trim(response.status==403) && $.trim(response.statusText)=='validation_error'){
                   $('#alertMsg').html('<div class="alert alert-warning alert-dismissible fade show" role="alert"><strong>Oops! </strong>'+response.loginData+'<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>');
                } 

               }
         });
      }
   });
  });
</script>