<!-- External JS libraries -->
<script src="<?php echo base_url();?>expertassets/js/jquery-2.2.0.min.js"></script>
<script src="<?php echo base_url();?>expertassets/js/popper.min.js"></script>
<script src="<?php echo base_url();?>expertassets/js/bootstrap.min.js"></script>
<!-- Custom JS Script -->
  </html>