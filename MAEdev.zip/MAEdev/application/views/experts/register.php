<?php require_once('header.php');?>

<body id="top" class="bg-color-8">
<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-TAGCODE"
                  height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->
<div class="page_loader"></div>

<!-- Login 8 start -->
<div class="login-8">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12">
                <div class="login-inner-form">
                    <div class="logo-2">
                        <a href="#">
                            <img src="<?php echo base_url();?>expertassets/img/logo.png" alt="logo">
                        </a>
                    </div>
                    <div class="details">
                      <?php if(!empty($this->session->flashdata('msg'))){ 
                         if($this->session->flashdata('msg')==='success'){
                            $msg = 'Expert Registered Successfully.';
                            $colorAlert = 'success';
                         }elseif($this->session->flashdata('msg')==='dberror'){
                            $msg = 'Some Database Error.';
                            $colorAlert = 'warning';
                         }
                         elseif($this->session->flashdata('msg')==='exist'){
                            $msg = 'Expert Already Register With Us.';
                            $colorAlert = 'warning';
                         }
                        ?>                      
                     <div class="alert alert-<?php echo $colorAlert;?> alert-dismissible">
                       <button type="button" class="close" data-dismiss="alert">&times;</button>
                       <strong>Message!</strong> <?php echo $msg;?>
                        </div>
                      <?php } ?>  
                      <div></div>  
                        <h3>Create an account</h3>
                        <form action="<?php echo base_url();?>expert_register" method="post">
                            <div class="form-group form-box">
                                <input type="text" name="fullname" class="input-text" placeholder="Full Name" required>
                                <i class="flaticon-user"></i>
                            </div>
							 <div class="form-group form-box">
                                <input type="text" name="phone" class="input-text" placeholder="Phone" required>
                                <i class="flaticon-user"></i>
                            </div>
							
                            <div class="form-group form-box">
                                <input type="email" name="email" class="input-text" placeholder="Email Address" required>
                                <i class="flaticon-mail-2"></i>
                            </div>
                            <div class="form-group form-box">
                                <input type="password" name="Password" class="input-text" placeholder="Password" required>
                                <i class="flaticon-password"></i>
                            </div>

							<div class="form-group form-box">
                                <input type="text" name="qualification" class="input-text" placeholder="Qualification" required>
                                <i class="flaticon-password"></i>
                            </div>

							<div class="form-group form-box">
                                <input type="text" name="expertise" class="input-text" placeholder="Area of Expertise" required>
                                <i class="flaticon-user"></i>
                            </div>
                            <div class="form-group form-box" style="width: auto;">
                            <label>Availability</label>
                            <label class="radio-inline"><input type="checkbox" name="availability[]" value="5" class="5_7_days" 
                                id="5_days" checked>5 days</label>
                            <label class="radio-inline"><input type="checkbox" name="availability[]" value="7" class="5_7_days"
                                  id="7_days">7 days</label>
                            <label class="radio-inline"><input type="checkbox" name="availability[]" value="24X7" >24X7</label>
                            </div>					
							
                            <div class="form-group form-box">
                            <select class="form-control" name="available_time" required>
                                <option value="">Select Time</option>
                                <?php if(isset($timeSlots)){

                                    foreach ($timeSlots as $key => $value) {
                                        echo '<option value="'.$value.'">'.$value.'</option>';
                                    }

                                }
                                ?>
                            </select>
                            </div>

							<div class="form-group form-box">
							<textarea class="form-control" rows="2" id="comment" name="address" placeholder="Address" required></textarea>
							</div>
							
							 <div class="form-group form-box">
                                <input type="text" name="cost_per_page" class="input-text ecost" placeholder="Expected Cost for 1 Page">
                          
                            </div>
							
                            <div class="checkbox clearfix">
                                <div class="form-check checkbox-theme">
                                    <input class="form-check-input" type="checkbox" name="agree_term" value="1" id="agree_term" required>
                                    <label class="form-check-label" for="agree_term">
                                        I agree to the<a href="javascript:void(0);" class="terms">terms of service</a>
                                    </label>
                                </div>
                            </div>
                            <div class="form-group mb-0">
                                <button type="submit" class="btn-md btn-theme btn-block">Register</button>
                            </div>
                            <div class="extra-login">
                                <span>Or Login With</span>
                            </div>
                            <ul class="social-list clearfix">
                                <li><a href="#" class="facebook-bg">Facebook</a></li>
                                <li><a href="#" class="twitter-bg">Twitter</a></li>
                                <li><a href="#" class="google-bg">Google</a></li>
                            </ul>
                        </form>
                    </div>
                    <p>Already a member? <a href="<?php echo base_url();?>expert" class="thembo"> Login here</a></p>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
<?php require_once('footer.php');?>

<script type="text/javascript">
   $(document).ready(function(){
    $('.5_7_days').on('change',function(){
     var value = $(this).val();     
     if($.trim(value)==5){
        $('#7_days').attr('checked',false);
     }
     if($.trim(value)==7){
        $('#5_days').attr('checked',false);
     }
    });
   }); 
</script>