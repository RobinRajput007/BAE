<?php require_once('header.php');?>
<body id="top" class="bg-color-8">
<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-TAGCODE"
                  height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->
<div class="page_loader"></div>

<!-- Login 8 start -->
<div class="login-8">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12">
                <div class="login-inner-form">
                    <div class="logo-2">
                        <a href="#">
                            <img src="<?php echo base_url();?>expertassets/img/logo.png" alt="logo">
                        </a>
                    </div>
                    <div class="details">
                        <h3>Recover your password</h3>
                        <form  id="formData">
                            <div class="form-group form-box">
                                <input type="email" name="email" class="input-text" placeholder="Email Address" id="email">
                                <i class="flaticon-mail-2"></i>
                                <span id="email_err"></span>
                            </div>
                            <div class="form-group mb-0">
                                <button type="button" class="btn-md btn-theme btn-block" id="sendEmail">Send Me Email</button>
                            </div>                            
                        </form>
                    </div>
                    <p>Already a member?<a href="<?php echo base_url();?>expert" class="thembo"> Login here</a></p>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
<?php require_once('footer.php');?>

<script type="text/javascript">
  $(document).ready(function(){
  
    $('#sendEmail').on('click',function(){
        var email = $('#email').val();
        var proceed = true;
        if(email=='' || email.length==0){
            proceed= false;
            $('#email').focus().css('border-color','#FF0000');
            return false;
        }
        else if(validateEmail(email)){           
             proceed= true;
            $('#email').focusout().css('border-color','');
            $('#email_err').html('');
        }else{
            proceed= false;
            $('#email').focus().css('border-color','#FF0000');
            $('#email_err').html('Invalid Email Address').css({'color':'#FF0000','font-size':'10px;','font-family':'Times New Roman", Times, serif;'});
            return false;
        }

        if(proceed){
            $.ajax({
                  type:'post',
                  url:'<?php echo base_url()?>sendforgot_mail',
                  data:{'email':email},
                  success:function(html){
                    alert(html);
                    if($.trim(html)==='mail_success'){
                     alert(html);
                    }
                    else if($.trim(html)==='mail_send_err'){
                    alert(html);
                    }
                    else if($.trim(html)==='mail_send_err'){
                      alert(html);
                    }

                  }
            });
        }
    });

    // Function that validates email address through a regular expression.
     function validateEmail(sEmail) {
        var filter = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
        if (filter.test(sEmail)) {
        return true;
        }
        else {
        return false;
        }
     }

  });  
</script>