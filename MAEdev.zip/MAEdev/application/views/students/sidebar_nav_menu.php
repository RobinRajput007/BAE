<nav class="sidebar sidebar-offcanvas" id="sidebar">
        <ul class="nav">
          <li class="nav-item">
            <a class="nav-link" href="<?php echo base_url();?>student_dashboard">
              <i class="ti-home menu-icon"></i>
              <span class="menu-title">Dashboard</span>
            </a>
          </li>
		      
		<li class="nav-item">
            <a class="nav-link" href="<?php echo base_url();?>all_assignments">
			<i class="ti-clipboard menu-icon"></i>
              <span class="menu-title">All Assignments</span>
             </a>
          </li>
		  
		   <li class="nav-item">
             <a class="nav-link" href="#">
            <i class="ti-write menu-icon"></i>
              <span class="menu-title">Add New Assignment</span>
            </a>
          </li>
		
		   <li class="nav-item">
            <a class="nav-link" href="#"> 
          <i class="ti-home menu-icon"></i>
              <span class="menu-title">Wallet </span>
            </a>
          </li>
		  
		    <li class="nav-item">
           <a class="nav-link" href="#">
              <i class="ti-layers menu-icon"></i>
              <span class="menu-title">Referal </span>
            </a>
          </li>
		  
		 
          <li class="nav-item">
            <a class="nav-link" href="<?php echo base_url();?>logout">
              <i class="ti-check-box menu-icon"></i>
              <span class="menu-title">Logout</span>
            </a>
          </li>
          
        </ul>
      </nav>