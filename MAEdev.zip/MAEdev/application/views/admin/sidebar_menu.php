  <!-- start sidebar menu -->
      <div class="sidebar-container">
        <div class="sidemenu-container navbar-collapse collapse fixed-menu">
          <div id="remove-scroll" class="left-sidemenu">
            <ul class="sidemenu  page-header-fixed sidemenu-hover-submenu" data-keep-expanded="false"
              data-auto-scroll="true" data-slide-speed="200" style="padding-top: 20px">
              <li class="sidebar-toggler-wrapper hide">
                <div class="sidebar-toggler">
                  <span></span>
                </div>
              </li>
              <li class="sidebar-user-panel">
                <div class="user-panel">
                  <div class="pull-left image">
                    <img src="<?php echo base_url();?>adminassets/assets/img/dp.jpg" class="img-circle user-img-circle"
                      alt="User Image" />
                  </div>
                  <div class="pull-left info">
                    <p> Kiran Patel</p>
                    <a href="#"><i class="fa fa-circle user-online"></i><span class="txtOnline">
                        Online</span></a>
                  </div>
                </div>
              </li>
              <li class="nav-item start active open">
                <a href="<?php echo base_url();?>admin_dashboard" class="nav-link nav-toggle">
                  <i class="material-icons">dashboard</i>
                  <span class="title">Dashboard</span>
                </a>
              
              </li>
              <li class="nav-item">
                <a href="event.html" class="nav-link nav-toggle"> <i class="material-icons">description</i>
                  <span class="title">Fresh Assignments</span>
                </a>
              </li>
              
              <li class="nav-item">
                <a href="event.html" class="nav-link nav-toggle"> <i class="material-icons">description</i>
                  <span class="title">Passed Assignments</span>
                </a>
              </li>
              
              <li class="nav-item">
                <a href="event.html" class="nav-link nav-toggle"> <i class="material-icons">description</i>
                  <span class="title">Failed Assignments</span>
                </a>
              </li>
              
              
              <li class="nav-item">
                <a href="event.html" class="nav-link nav-toggle"> <i class="material-icons">description</i>
                  <span class="title">Sample/Paid-Free</span>
                </a>
              </li>
              
              <li class="nav-item">
                <a href="event.html" class="nav-link nav-toggle"> <i class="material-icons">description</i>
                  <span class="title">Download Student/Experts Data</span>
                </a>
              </li>
              
              <li class="nav-item">
                <a href="event.html" class="nav-link nav-toggle"> <i class="material-icons">description</i>
                  <span class="title">Add/Deduct Money to/From Wallet</span>
                </a>
              </li>
          
        <li class="nav-item">
                <a href="event.html" class="nav-link nav-toggle"> <i class="material-icons">description</i>
                  <span class="title">Forget Password</span>
                </a>
              </li> 
              
                
              
               <li class="nav-item">
                <a href="event.html" class="nav-link nav-toggle"> <i class="material-icons">description</i>
                  <span class="title">Subscribers</span>
                </a>
              </li> 
              
               <li class="nav-item">
                <a href="event.html" class="nav-link nav-toggle"> <i class="material-icons">description</i>
                  <span class="title">Call Backs</span>
                </a>
              </li> 
              
               <li class="nav-item">
                <a href="event.html" class="nav-link nav-toggle"> <i class="material-icons">description</i>
                  <span class="title">Contact us Requests</span>
                </a>
              </li>               
            
            </ul>
          </div>
        </div>
      </div>
      <!-- end sidebar menu -->