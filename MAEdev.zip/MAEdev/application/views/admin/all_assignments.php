<?php require_once('header.php');?>

<body
  class="page-header-fixed sidemenu-closed-hidelogo page-content-white page-md header-white white-sidebar-color logo-indigo">
  <div class="page-wrapper">
      <!-- start header -->
    <div class="page-header navbar navbar-fixed-top">
      <div class="page-header-inner ">
        <!-- logo start -->
        <div class="page-logo">
          <a href="index.html">
            
            <span class="logo-default">BAE</span> </a>
        </div>
        <!-- logo end -->
        <ul class="nav navbar-nav navbar-left in">
          <li><a href="#" class="menu-toggler sidebar-toggler"><i class="icon-menu"></i></a></li>
        </ul>
        <form class="search-form-opened" action="#" method="GET">
          <div class="input-group">
            <input type="text" class="form-control" placeholder="Search Assignment" name="query">
            <span class="input-group-btn">
              <a href="javascript:;" class="btn submit">
                <i class="icon-magnifier"></i>
              </a>
            </span>
          </div>
        </form>
        
        <form class="search-form-opened" action="#" method="GET">
          <div class="input-group">
            <input type="text" class="form-control" placeholder="Search Student" name="query">
            <span class="input-group-btn">
              <a href="javascript:;" class="btn submit">
                <i class="icon-magnifier"></i>
              </a>
            </span>
          </div>
        </form>
        
        <form class="search-form-opened" action="#" method="GET">
          <div class="input-group">
            <input type="text" class="form-control" placeholder="Search Experts" name="query">
            <span class="input-group-btn">
              <a href="javascript:;" class="btn submit">
                <i class="icon-magnifier"></i>
              </a>
            </span>
          </div>
        </form>
        <!-- start mobile menu -->
        <a href="javascript:;" class="menu-toggler responsive-toggler" data-toggle="collapse"
          data-target=".navbar-collapse">
          <span></span>
        </a>
        <!-- end mobile menu -->
        <!-- start header menu -->
        <div class="top-menu">
          <ul class="nav navbar-nav pull-right">
            <!-- start language menu -->
            
            <!-- end language menu -->
            <!-- start notification dropdown -->
            <li class="dropdown dropdown-extended dropdown-notification" id="header_notification_bar">
              <a href="javascript:;" class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown"
                data-close-others="true">
                <i class="fa fa-bell-o"></i>
                <span class="badge headerBadgeColor1"> 6 </span>
              </a>
              <ul class="dropdown-menu">
                <li class="external">
                  <h3><span class="bold">Notifications</span></h3>
                  <span class="notification-label purple-bgcolor">New 6</span>
                </li>
                <li>
                  <ul class="dropdown-menu-list small-slimscroll-style" data-handle-color="#637283">
                    <li>
                      <a href="javascript:;">
                        <span class="time">just now</span>
                        <span class="details">
                          <span class="notification-icon circle deepPink-bgcolor"><i
                              class="fa fa-check"></i></span>
                          Congratulations!. </span>
                      </a>
                    </li>
                    <li>
                      <a href="javascript:;">
                        <span class="time">3 mins</span>
                        <span class="details">
                          <span class="notification-icon circle purple-bgcolor"><i
                              class="fa fa-user o"></i></span>
                          <b>John Micle </b>is now following you. </span>
                      </a>
                    </li>
                    <li>
                      <a href="javascript:;">
                        <span class="time">7 mins</span>
                        <span class="details">
                          <span class="notification-icon circle blue-bgcolor"><i
                              class="fa fa-comments-o"></i></span>
                          <b>Sneha Jogi </b>sent you a message. </span>
                      </a>
                    </li>
                    <li>
                      <a href="javascript:;">
                        <span class="time">12 mins</span>
                        <span class="details">
                          <span class="notification-icon circle pink"><i
                              class="fa fa-heart"></i></span>
                          <b>Ravi Patel </b>like your photo. </span>
                      </a>
                    </li>
                    <li>
                      <a href="javascript:;">
                        <span class="time">15 mins</span>
                        <span class="details">
                          <span class="notification-icon circle yellow"><i
                              class="fa fa-warning"></i></span> Warning! </span>
                      </a>
                    </li>
                    <li>
                      <a href="javascript:;">
                        <span class="time">10 hrs</span>
                        <span class="details">
                          <span class="notification-icon circle red"><i
                              class="fa fa-times"></i></span> Application error. </span>
                      </a>
                    </li>
                  </ul>
                  <div class="dropdown-menu-footer">
                    <a href="javascript:void(0)"> All notifications </a>
                  </div>
                </li>
              </ul>
            </li>
            <!-- end notification dropdown -->
            
            <!-- start manage user dropdown -->
            <li class="dropdown dropdown-user">
              <a href="javascript:;" class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown"
                data-close-others="true">
                <img alt="" class="img-circle " src="assets/img/dp.jpg" />
                <span class="username username-hide-on-mobile"> Kiran </span>
                <i class="fa fa-angle-down"></i>
              </a>
              <ul class="dropdown-menu dropdown-menu-default">
                <li>
                  <a href="user_profile.html">
                    <i class="icon-user"></i> Profile </a>
                </li>
                <li>
                  <a href="#">
                    <i class="icon-settings"></i> Settings
                  </a>
                </li>
                <li>
                  <a href="#">
                    <i class="icon-directions"></i> Help
                  </a>
                </li>
                <li class="divider"> </li>
                <li>
                  <a href="lock_screen.html">
                    <i class="icon-lock"></i> Lock
                  </a>
                </li>
                <li>
                  <a href="login.html">
                    <i class="icon-logout"></i> Log Out </a>
                </li>
              </ul>
            </li>
            <!-- end manage user dropdown -->
            <li class="dropdown dropdown-quick-sidebar-toggler">
              <a id="headerSettingButton" class="mdl-button mdl-js-button mdl-button--icon pull-right"
                data-upgraded=",MaterialButton">
                <i class="material-icons">more_vert</i>
              </a>
            </li>
          </ul>
        </div>
      </div>
    </div>
    <!-- end header -->
  
    <!-- start page container -->
    <div class="page-container">
      <!-- start sidebar menu --> 
    <?php echo require_once('sidebar_menu.php');?>
      <!-- start page content -->
      <div class="page-content-wrapper">
        <div class="page-content">
          <div class="page-bar">
            <div class="page-title-breadcrumb">
              <div class=" pull-left">
                <div class="page-title"></div>
              </div>
              <ol class="breadcrumb page-breadcrumb pull-right">
                <li><i class="fa fa-home"></i>&nbsp;<a class="parent-item"
                    href="index.html">Home</a>&nbsp;<i class="fa fa-angle-right"></i>
                </li>
              
                <li class="active">All Assignments</li>
              </ol>
            </div>
          </div>
          <div class="row">
            <div class="col-md-12 col-sm-12">
              <div class="card card-box">
                <div class="card-head">
                  <header>All Assignments</header>
                  
                  
                </div>
                <div class="card-body " id="bar-parent">
                  <table id="exportTable" class="display nowrap table-striped table-responsive table-bordered table-hover" style="width:100%">
                    <thead>
                      <tr>
                        <th>Assignments</th>
                        <th>Subjects</th>
                        <th>Total Amount</th>
                        <th>Payment Paid</th>
                        <th>Payment Left</th>
                        <th>Submitted date</th>
                        <th>Due date</th>
                        <th>Experts</th>
                        <th>Action</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td><span class="label label-md label-warning">BAE-01082019-2058</span></td>
                        <td>System Architect</td>
                        <td>150USD</td>
                        <td>75USD</td>
                        <td>75USD</td>
                        <td>2019/04/25</td>
                        <td>2019/04/25</td>
                        <td>Expert</td>
                        <td>
                            <a href="#" class="btn btn-primary btn-xs" title="Edit">
                              <i class="fa fa-pencil"></i>
                            </a>
                            <button class="btn btn-danger btn-xs" title="Delete">
                              <i class="fa fa-trash-o "></i>
                            </button>
                            <a href="#" class="btn btn-success btn-xs" title="Allocate">
                              <i class="fa fa-file"></i>
                            </a>
                          </td>
                      </tr>
                      
                      <tr>
                        <td><span class="label label-md label-warning">BAE-01082019-2058</span></td>
                        <td>System Architect</td>
                        <td>150USD</td>
                        <td>75USD</td>
                        <td>75USD</td>
                        <td>2019/04/25</td>
                        <td>2019/04/25</td>
                        <td>Expert</td>
                        <td>
                            <a href="#" class="btn btn-primary btn-xs" title="Edit">
                              <i class="fa fa-pencil"></i>
                            </a>
                            <button class="btn btn-danger btn-xs" title="Delete">
                              <i class="fa fa-trash-o "></i>
                            </button>
                            <a href="#" class="btn btn-success btn-xs" title="Allocate">
                              <i class="fa fa-file"></i>
                            </a>
                          </td>
                      </tr>
                      
                      
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- end page content -->
      <!-- start chat sidebar -->
      <div class="chat-sidebar-container" data-close-on-body-click="false">
        <div class="chat-sidebar">
          <ul class="nav nav-tabs">
            <li class="nav-item">
              <a href="#quick_sidebar_tab_1" class="nav-link active tab-icon" data-toggle="tab"> <i
                  class="material-icons">chat</i>Chat
                <span class="badge badge-danger">4</span>
              </a>
            </li>
            <li class="nav-item">
              <a href="#quick_sidebar_tab_3" class="nav-link tab-icon" data-toggle="tab"> <i
                  class="material-icons">settings</i>
                Settings
              </a>
            </li>
          </ul>
          <div class="tab-content">
            <!-- Start User Chat -->
            <div class="tab-pane active chat-sidebar-chat in active show" role="tabpanel"
              id="quick_sidebar_tab_1">
              <div class="chat-sidebar-list">
                <div class="chat-sidebar-chat-users slimscroll-style" data-rail-color="#ddd"
                  data-wrapper-class="chat-sidebar-list">
                  <div class="chat-header">
                    <h5 class="list-heading">Online</h5>
                  </div>
                  <ul class="media-list list-items">
                    <li class="media"><img class="media-object" src="assets/img/prof/prof3.jpg"
                        width="35" height="35" alt="...">
                      <i class="online dot"></i>
                      <div class="media-body">
                        <h5 class="media-heading">John Deo</h5>
                        <div class="media-heading-sub">Spine Surgeon</div>
                      </div>
                    </li>
                    <li class="media">
                      <div class="media-status">
                        <span class="badge badge-success">5</span>
                      </div> <img class="media-object" src="assets/img/prof/prof1.jpg"
                        width="35" height="35" alt="...">
                      <i class="busy dot"></i>
                      <div class="media-body">
                        <h5 class="media-heading">Rajesh</h5>
                        <div class="media-heading-sub">Director</div>
                      </div>
                    </li>
                    <li class="media"><img class="media-object" src="assets/img/prof/prof5.jpg"
                        width="35" height="35" alt="...">
                      <i class="away dot"></i>
                      <div class="media-body">
                        <h5 class="media-heading">Jacob Ryan</h5>
                        <div class="media-heading-sub">Ortho Surgeon</div>
                      </div>
                    </li>
                    <li class="media">
                      <div class="media-status">
                        <span class="badge badge-danger">8</span>
                      </div> <img class="media-object" src="assets/img/prof/prof4.jpg"
                        width="35" height="35" alt="...">
                      <i class="online dot"></i>
                      <div class="media-body">
                        <h5 class="media-heading">Kehn Anderson</h5>
                        <div class="media-heading-sub">CEO</div>
                      </div>
                    </li>
                    <li class="media"><img class="media-object" src="assets/img/prof/prof2.jpg"
                        width="35" height="35" alt="...">
                      <i class="busy dot"></i>
                      <div class="media-body">
                        <h5 class="media-heading">Sarah Smith</h5>
                        <div class="media-heading-sub">Anaesthetics</div>
                      </div>
                    </li>
                    <li class="media"><img class="media-object" src="assets/img/prof/prof7.jpg"
                        width="35" height="35" alt="...">
                      <i class="online dot"></i>
                      <div class="media-body">
                        <h5 class="media-heading">Vlad Cardella</h5>
                        <div class="media-heading-sub">Cardiologist</div>
                      </div>
                    </li>
                  </ul>
                  <div class="chat-header">
                    <h5 class="list-heading">Offline</h5>
                  </div>
                  <ul class="media-list list-items">
                    <li class="media">
                      <div class="media-status">
                        <span class="badge badge-warning">4</span>
                      </div> <img class="media-object" src="assets/img/prof/prof6.jpg"
                        width="35" height="35" alt="...">
                      <i class="offline dot"></i>
                      <div class="media-body">
                        <h5 class="media-heading">Jennifer Maklen</h5>
                        <div class="media-heading-sub">Nurse</div>
                        <div class="media-heading-small">Last seen 01:20 AM</div>
                      </div>
                    </li>
                    <li class="media"><img class="media-object" src="assets/img/prof/prof8.jpg"
                        width="35" height="35" alt="...">
                      <i class="offline dot"></i>
                      <div class="media-body">
                        <h5 class="media-heading">Lina Smith</h5>
                        <div class="media-heading-sub">Ortho Surgeon</div>
                        <div class="media-heading-small">Last seen 11:14 PM</div>
                      </div>
                    </li>
                    <li class="media">
                      <div class="media-status">
                        <span class="badge badge-success">9</span>
                      </div> <img class="media-object" src="assets/img/prof/prof9.jpg"
                        width="35" height="35" alt="...">
                      <i class="offline dot"></i>
                      <div class="media-body">
                        <h5 class="media-heading">Jeff Adam</h5>
                        <div class="media-heading-sub">Compounder</div>
                        <div class="media-heading-small">Last seen 3:31 PM</div>
                      </div>
                    </li>
                    <li class="media"><img class="media-object" src="assets/img/prof/prof10.jpg"
                        width="35" height="35" alt="...">
                      <i class="offline dot"></i>
                      <div class="media-body">
                        <h5 class="media-heading">Anjelina Cardella</h5>
                        <div class="media-heading-sub">Physiotherapist</div>
                        <div class="media-heading-small">Last seen 7:45 PM</div>
                      </div>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
            <!-- End User Chat -->
            <!-- Start Setting Panel -->
            <div class="tab-pane chat-sidebar-settings" role="tabpanel" id="quick_sidebar_tab_3">
              <div class="chat-sidebar-settings-list slimscroll-style">
                <div class="chat-header">
                  <h5 class="list-heading">Layout Settings</h5>
                </div>
                <div class="chatpane inner-content ">
                  <div class="settings-list">
                    <div class="setting-item">
                      <div class="setting-text">Sidebar Position</div>
                      <div class="setting-set">
                        <select
                          class="sidebar-pos-option form-control input-inline input-sm input-small ">
                          <option value="left" selected="selected">Left</option>
                          <option value="right">Right</option>
                        </select>
                      </div>
                    </div>
                    <div class="setting-item">
                      <div class="setting-text">Header</div>
                      <div class="setting-set">
                        <select
                          class="page-header-option form-control input-inline input-sm input-small ">
                          <option value="fixed" selected="selected">Fixed</option>
                          <option value="default">Default</option>
                        </select>
                      </div>
                    </div>
                    <div class="setting-item">
                      <div class="setting-text">Footer</div>
                      <div class="setting-set">
                        <select
                          class="page-footer-option form-control input-inline input-sm input-small ">
                          <option value="fixed">Fixed</option>
                          <option value="default" selected="selected">Default</option>
                        </select>
                      </div>
                    </div>
                  </div>
                  <div class="chat-header">
                    <h5 class="list-heading">Account Settings</h5>
                  </div>
                  <div class="settings-list">
                    <div class="setting-item">
                      <div class="setting-text">Notifications</div>
                      <div class="setting-set">
                        <div class="switch">
                          <label class="mdl-switch mdl-js-switch mdl-js-ripple-effect"
                            for="switch-1">
                            <input type="checkbox" id="switch-1" class="mdl-switch__input"
                              checked>
                          </label>
                        </div>
                      </div>
                    </div>
                    <div class="setting-item">
                      <div class="setting-text">Show Online</div>
                      <div class="setting-set">
                        <div class="switch">
                          <label class="mdl-switch mdl-js-switch mdl-js-ripple-effect"
                            for="switch-7">
                            <input type="checkbox" id="switch-7" class="mdl-switch__input"
                              checked>
                          </label>
                        </div>
                      </div>
                    </div>
                    <div class="setting-item">
                      <div class="setting-text">Status</div>
                      <div class="setting-set">
                        <div class="switch">
                          <label class="mdl-switch mdl-js-switch mdl-js-ripple-effect"
                            for="switch-2">
                            <input type="checkbox" id="switch-2" class="mdl-switch__input"
                              checked>
                          </label>
                        </div>
                      </div>
                    </div>
                    <div class="setting-item">
                      <div class="setting-text">2 Steps Verification</div>
                      <div class="setting-set">
                        <div class="switch">
                          <label class="mdl-switch mdl-js-switch mdl-js-ripple-effect"
                            for="switch-3">
                            <input type="checkbox" id="switch-3" class="mdl-switch__input"
                              checked>
                          </label>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="chat-header">
                    <h5 class="list-heading">General Settings</h5>
                  </div>
                  <div class="settings-list">
                    <div class="setting-item">
                      <div class="setting-text">Location</div>
                      <div class="setting-set">
                        <div class="switch">
                          <label class="mdl-switch mdl-js-switch mdl-js-ripple-effect"
                            for="switch-4">
                            <input type="checkbox" id="switch-4" class="mdl-switch__input"
                              checked>
                          </label>
                        </div>
                      </div>
                    </div>
                    <div class="setting-item">
                      <div class="setting-text">Save Histry</div>
                      <div class="setting-set">
                        <div class="switch">
                          <label class="mdl-switch mdl-js-switch mdl-js-ripple-effect"
                            for="switch-5">
                            <input type="checkbox" id="switch-5" class="mdl-switch__input"
                              checked>
                          </label>
                        </div>
                      </div>
                    </div>
                    <div class="setting-item">
                      <div class="setting-text">Auto Updates</div>
                      <div class="setting-set">
                        <div class="switch">
                          <label class="mdl-switch mdl-js-switch mdl-js-ripple-effect"
                            for="switch-6">
                            <input type="checkbox" id="switch-6" class="mdl-switch__input"
                              checked>
                          </label>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- end chat sidebar -->
    </div>
    <!-- end page container -->    
  <?php require_once('footer.php');?>  
</body>
