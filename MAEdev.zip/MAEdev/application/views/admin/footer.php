<!-- start footer -->
    <div class="page-footer">
      <div class="page-footer-inner"> 2019 &copy; Best Assignment Experts By
        <a href="" target="_top" class="makerCss">INASoftsolutions.com</a>
      </div>
      <div class="scroll-to-top">
        <i class="icon-arrow-up"></i>
      </div>
    </div>
    <!-- end footer -->
  </div>    
  
<!-- start js include path -->
  <script src="<?php echo base_url();?>adminassets/assets/plugins/jquery/jquery.min.js"></script>
  <script src="<?php echo base_url();?>adminassets/assets/plugins/popper/popper.js"></script>
  <script src="<?php echo base_url();?>adminassets/assets/plugins/jquery-blockui/jquery.blockui.min.js"></script>
  <script src="<?php echo base_url();?>adminassets/assets/plugins/jquery-slimscroll/jquery.slimscroll.js"></script>
  <!-- bootstrap -->
  <script src="<?php echo base_url();?>adminassets/assets/plugins/bootstrap/js/bootstrap.min.js"></script>
  <script src="<?php echo base_url();?>adminassets/assets/plugins/bootstrap-switch/js/bootstrap-switch.min.js"></script>
  <script src="<?php echo base_url();?>adminassets/assets/plugins/sparkline/jquery.sparkline.js"></script>
  <script src="<?php echo base_url();?>adminassets/assets/js/pages/sparkline/sparkline-data.js"></script>
  <!-- data tables -->
  <script src="<?php echo base_url();?>adminassets/assets/plugins/datatables/jquery.dataTables.min.js"></script>
  <script src="<?php echo base_url();?>adminassets/assets/plugins/datatables/plugins/bootstrap/dataTables.bootstrap4.min.js"></script>
  <script src="<?php echo base_url();?>adminassets/assets/js/pages/table/table_data.js"></script>

  <!-- Common js-->
  <script src="<?php echo base_url();?>adminassets/assets/js/app.js"></script>
  <script src="<?php echo base_url();?>adminassets/assets/js/layout.js"></script>
  <script src="<?php echo base_url();?>adminassets/assets/js/theme-color.js"></script>
  <!-- material -->
  <script src="<?php echo base_url();?>adminassets/assets/plugins/material/material.min.js"></script>
  
  </html>