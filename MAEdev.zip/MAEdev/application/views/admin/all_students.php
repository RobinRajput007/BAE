<?php require_once('header.php');?>

<body
  class="page-header-fixed sidemenu-closed-hidelogo page-content-white page-md header-white white-sidebar-color logo-indigo">
  <div class="page-wrapper">
      <!-- start header -->
    <div class="page-header navbar navbar-fixed-top">
      <div class="page-header-inner ">
        <!-- logo start -->
        <div class="page-logo">
          <a href="index.html">
            
            <span class="logo-default">BAE</span> </a>
        </div>
        <!-- logo end -->
        <ul class="nav navbar-nav navbar-left in">
          <li><a href="#" class="menu-toggler sidebar-toggler"><i class="icon-menu"></i></a></li>
        </ul>
        <form class="search-form-opened" action="#" method="GET">
          <div class="input-group">
            <input type="text" class="form-control" placeholder="Search Assignment" name="query">
            <span class="input-group-btn">
              <a href="javascript:;" class="btn submit">
                <i class="icon-magnifier"></i>
              </a>
            </span>
          </div>
        </form>
        
        <form class="search-form-opened" action="#" method="GET">
          <div class="input-group">
            <input type="text" class="form-control" placeholder="Search Student" name="query">
            <span class="input-group-btn">
              <a href="javascript:;" class="btn submit">
                <i class="icon-magnifier"></i>
              </a>
            </span>
          </div>
        </form>
        
        <form class="search-form-opened" action="#" method="GET">
          <div class="input-group">
            <input type="text" class="form-control" placeholder="Search Experts" name="query">
            <span class="input-group-btn">
              <a href="javascript:;" class="btn submit">
                <i class="icon-magnifier"></i>
              </a>
            </span>
          </div>
        </form>
        <!-- start mobile menu -->
        <a href="javascript:;" class="menu-toggler responsive-toggler" data-toggle="collapse"
          data-target=".navbar-collapse">
          <span></span>
        </a>
        <!-- end mobile menu -->
        <!-- start header menu -->
        <div class="top-menu">
          <ul class="nav navbar-nav pull-right">
            <!-- start language menu -->
            
            <!-- end language menu -->
            <!-- start notification dropdown -->
            <li class="dropdown dropdown-extended dropdown-notification" id="header_notification_bar">
              <a href="javascript:;" class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown"
                data-close-others="true">
                <i class="fa fa-bell-o"></i>
                <span class="badge headerBadgeColor1"> 6 </span>
              </a>
              <ul class="dropdown-menu">
                <li class="external">
                  <h3><span class="bold">Notifications</span></h3>
                  <span class="notification-label purple-bgcolor">New 6</span>
                </li>
                <li>
                  <ul class="dropdown-menu-list small-slimscroll-style" data-handle-color="#637283">
                    <li>
                      <a href="javascript:;">
                        <span class="time">just now</span>
                        <span class="details">
                          <span class="notification-icon circle deepPink-bgcolor"><i
                              class="fa fa-check"></i></span>
                          Congratulations!. </span>
                      </a>
                    </li>
                    <li>
                      <a href="javascript:;">
                        <span class="time">3 mins</span>
                        <span class="details">
                          <span class="notification-icon circle purple-bgcolor"><i
                              class="fa fa-user o"></i></span>
                          <b>John Micle </b>is now following you. </span>
                      </a>
                    </li>
                    <li>
                      <a href="javascript:;">
                        <span class="time">7 mins</span>
                        <span class="details">
                          <span class="notification-icon circle blue-bgcolor"><i
                              class="fa fa-comments-o"></i></span>
                          <b>Sneha Jogi </b>sent you a message. </span>
                      </a>
                    </li>
                    <li>
                      <a href="javascript:;">
                        <span class="time">12 mins</span>
                        <span class="details">
                          <span class="notification-icon circle pink"><i
                              class="fa fa-heart"></i></span>
                          <b>Ravi Patel </b>like your photo. </span>
                      </a>
                    </li>
                    <li>
                      <a href="javascript:;">
                        <span class="time">15 mins</span>
                        <span class="details">
                          <span class="notification-icon circle yellow"><i
                              class="fa fa-warning"></i></span> Warning! </span>
                      </a>
                    </li>
                    <li>
                      <a href="javascript:;">
                        <span class="time">10 hrs</span>
                        <span class="details">
                          <span class="notification-icon circle red"><i
                              class="fa fa-times"></i></span> Application error. </span>
                      </a>
                    </li>
                  </ul>
                  <div class="dropdown-menu-footer">
                    <a href="javascript:void(0)"> All notifications </a>
                  </div>
                </li>
              </ul>
            </li>
            <!-- end notification dropdown -->
            
            <!-- start manage user dropdown -->
            <li class="dropdown dropdown-user">
              <a href="javascript:;" class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown"
                data-close-others="true">
                <img alt="" class="img-circle " src="<?php echo base_url();?>adminassets/assets/img/dp.jpg" />
                <span class="username username-hide-on-mobile"> Kiran </span>
                <i class="fa fa-angle-down"></i>
              </a>
              <ul class="dropdown-menu dropdown-menu-default">
                <li>
                  <a href="user_profile.html">
                    <i class="icon-user"></i> Profile </a>
                </li>
                <li>
                  <a href="#">
                    <i class="icon-settings"></i> Settings
                  </a>
                </li>
                <li>
                  <a href="#">
                    <i class="icon-directions"></i> Help
                  </a>
                </li>
                <li class="divider"> </li>
                <li>
                  <a href="lock_screen.html">
                    <i class="icon-lock"></i> Lock
                  </a>
                </li>
                <li>
                  <a href="<?php echo base_url();?>admin_logout">
                    <i class="icon-logout"></i> Log Out </a>
                </li>
              </ul>
            </li>
            <!-- end manage user dropdown -->
            <li class="dropdown dropdown-quick-sidebar-toggler">
              <a id="headerSettingButton" class="mdl-button mdl-js-button mdl-button--icon pull-right"
                data-upgraded=",MaterialButton">
                <i class="material-icons">more_vert</i>
              </a>
            </li>
          </ul>
        </div>
      </div>
    </div>
    <!-- end header -->
  
    <!-- start page container -->
    <div class="page-container">
     <!-- start sidebar menu --> 
    <?php echo require_once('sidebar_menu.php');?>
      <!-- start page content -->
      <div class="page-content-wrapper">
        <div class="page-content">
          <div class="page-bar">
            <div class="page-title-breadcrumb">
              <div class=" pull-left">
                <div class="page-title">All Experts List</div>
              </div>
              <ol class="breadcrumb page-breadcrumb pull-right">
                <li><i class="fa fa-home"></i>&nbsp;<a class="parent-item"
                    href="index.html">Home</a>&nbsp;<i class="fa fa-angle-right"></i>
                </li>
                
                <li class="active">All Students</li>
              </ol>
            </div>
          </div>
          <div class="row">
            <div class="col-md-12">
              <div class="tabbable-line">
                <!-- <ul class="nav nav-tabs">
                                    <li class="active">
                                        <a href="#tab1" data-toggle="tab"> List View </a>
                                    </li>
                                    <li>
                                        <a href="#tab2" data-toggle="tab"> Grid View </a>
                                    </li>
                                </ul> -->
                <ul class="nav customtab nav-tabs" role="tablist">
                  <li class="nav-item"><a href="#tab1" class="nav-link active" data-toggle="tab">List
                      View</a></li>
                  <li class="nav-item"><a href="#tab2" class="nav-link" data-toggle="tab">Grid
                      View</a></li>
                </ul>
                <div class="tab-content">
                  <div class="tab-pane active fontawesome-demo" id="tab1">
                    <div class="row">
                      <div class="col-md-12">
                        <div class="card card-box">
                          <div class="card-head">
                            <header>All Students</header>
                            <div id="alertMsg"></div>
                            <div class="tools">
                              <a class="fa fa-repeat btn-color box-refresh"
                                href="javascript:;"></a>
                              <a class="t-collapse btn-color fa fa-chevron-down"
                                href="javascript:;"></a>
                              <a class="t-close btn-color fa fa-times"
                                href="javascript:;"></a>
                            </div>
                          </div>
                          <div class="card-body ">
                            <div class="row">
                              <div class="col-md-6 col-sm-6 col-6">
                                
                              </div>
                              <div class="col-md-6 col-sm-6 col-6">
                                <div class="btn-group pull-right">
                                  <a class="btn deepPink-bgcolor  btn-outline dropdown-toggle"
                                    data-toggle="dropdown">Tools
                                    <i class="fa fa-angle-down"></i>
                                  </a>
                                  <ul class="dropdown-menu pull-right">
                                    <li>
                                      <a href="javascript:;">
                                        <i class="fa fa-print"></i> Print </a>
                                    </li>
                                    <li>
                                      <a href="javascript:;">
                                        <i class="fa fa-file-pdf-o"></i> Save as
                                        PDF </a>
                                    </li>
                                    <li>
                                      <a href="javascript:;">
                                        <i class="fa fa-file-excel-o"></i>
                                        Export to Excel </a>
                                    </li>
                                  </ul>
                                </div>
                              </div>
                            </div>
                            <div class="table-scrollable">
                              <table
                                class="table table-striped table-bordered table-hover table-checkable order-column valign-middle"
                                id="example4">
                                <thead>
                                  <tr>
                                    <th>#</th>
                                    <th> Name </th>
                                    <th> Id </th>
                                    <th> Mobile </th>
                                    <th> Email </th>
                                    <th>Assignments</th>
                                    <th>Wallet</th>
                                    <th>Referral</th>
                                    <th> Action </th>
                                  </tr>
                                </thead>
                                <tbody>
                                 <?php 
                                  foreach ($studentData as $key => $value): 
                                 ?> 
                                  <tr class="odd gradeX" id="del_<?php echo $value->id;?>">
                                    <td class="patient-img">
                                      <?php 
                                       if(isset($value->image_url)){
                                         $studentPic = $value->image_url;
                                       }else{
                                        $studentPic = base_url().'adminassets/assets/img/prof/placeholder.jpg';
                                       }
                                      ?>
                                      <img src="<?php echo $studentPic;?>" alt="student pic">
                                    </td>
                                    <td><?php echo $value->name;?></td>
                                    <td><span class="label label-md label-warning"><?php echo $value->id;?></span></td>
                                    <td class="left"><?php echo $value->phone;?></td>
                                    <td><a href="mailto:<?php echo $value->email;?>"><?php echo $value->email;?></a></td>
                                    <td class="left">01</td>
                                    <td class="left">$20</td>
                                    <td class="left">$0</td>
                                    <td>
                                      <a href="javascript:void(0);" class="btn btn-primary btn-xs editStudent" data-id="<?php echo $value->id;?>">
                                        <i class="fa fa-pencil"></i>
                                      </a>
                                      <a href="javascript:void(0);" class="btn btn-danger btn-xs deleteStudent" data-id="<?php echo $value->id;?>">
                                        <i class="fa fa-trash-o "></i>
                                      </a>
                                    </td>
                                  </tr>
                                <?php endforeach;?>
                                  
                                </tbody>
                              </table>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="tab-pane" id="tab2">
                    <div class="row">
                      <?php 
                        foreach ($studentData as $key => $gridview): 
                       ?> 
                      <div class="col-md-4">
                        <div class="card card-box">
                          <div class="card-body no-padding ">
                            <div class="doctor-profile">
                              <?php 
                               if(isset($gridview->image_url)){
                                 $studentgridPic = $gridview->image_url;
                               }else{
                                $studentgridPic = base_url().'adminassets/assets/img/prof/placeholder.jpg';
                               }
                              ?>
                              <img src="<?php echo $studentgridPic;?>" class="doctor-pic" alt="student-grid-pic">
                              <div class="profile-usertitle">
                                <div class="doctor-name"><?php echo $gridview->name;?> </div>
                              </div>
                                <div>
                                <p><i class="fa fa-envelope"></i><a
                                    href="mailto:<?php echo $gridview->email;?>"> <?php echo $gridview->email;?></a></p>
                              </div>
                              <div>
                                <p><i class="fa fa-phone"></i>(+<?php echo $gridview->country_code;?>) - <?php echo $gridview->phone;?></p>
                              </div>
                              <div class="profile-userbuttons">
                                <a href="professor_profile.html" class="btn btn-circle deepPink-bgcolor btn-sm" 
                                    data-id="<?php echo $gridview->id;?>">Read More</a>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <?php endforeach;?>                      
                  
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- end page content -->
      <!-- start chat sidebar -->
      <div class="chat-sidebar-container" data-close-on-body-click="false">
        <div class="chat-sidebar">
          <ul class="nav nav-tabs">
            <li class="nav-item">
              <a href="#quick_sidebar_tab_1" class="nav-link active tab-icon" data-toggle="tab"> <i
                  class="material-icons">chat</i>Chat
                <span class="badge badge-danger">4</span>
              </a>
            </li>
            <li class="nav-item">
              <a href="#quick_sidebar_tab_3" class="nav-link tab-icon" data-toggle="tab"> <i
                  class="material-icons">settings</i>
                Settings
              </a>
            </li>
          </ul>
          <div class="tab-content">
            <!-- Start User Chat -->
            <div class="tab-pane active chat-sidebar-chat in active show" role="tabpanel"
              id="quick_sidebar_tab_1">
              <div class="chat-sidebar-list">
                <div class="chat-sidebar-chat-users slimscroll-style" data-rail-color="#ddd"
                  data-wrapper-class="chat-sidebar-list">
                  <div class="chat-header">
                    <h5 class="list-heading">Online</h5>
                  </div>
                  <ul class="media-list list-items">
                    <li class="media"><img class="media-object" src="<?php echo base_url();?>adminassets/assets/img/prof/prof3.jpg"
                        width="35" height="35" alt="...">
                      <i class="online dot"></i>
                      <div class="media-body">
                        <h5 class="media-heading">John Deo</h5>
                        <div class="media-heading-sub">Spine Surgeon</div>
                      </div>
                    </li>
                    <li class="media">
                      <div class="media-status">
                        <span class="badge badge-success">5</span>
                      </div> <img class="media-object" src="<?php echo base_url();?>adminassets/assets/img/prof/prof1.jpg"
                        width="35" height="35" alt="...">
                      <i class="busy dot"></i>
                      <div class="media-body">
                        <h5 class="media-heading">Rajesh</h5>
                        <div class="media-heading-sub">Director</div>
                      </div>
                    </li>
                    <li class="media"><img class="media-object" src="<?php echo base_url();?>adminassets/assets/img/prof/prof5.jpg"
                        width="35" height="35" alt="...">
                      <i class="away dot"></i>
                      <div class="media-body">
                        <h5 class="media-heading">Jacob Ryan</h5>
                        <div class="media-heading-sub">Ortho Surgeon</div>
                      </div>
                    </li>
                    <li class="media">
                      <div class="media-status">
                        <span class="badge badge-danger">8</span>
                      </div> <img class="media-object" src="<?php echo base_url();?>adminassets/assets/img/prof/prof4.jpg"
                        width="35" height="35" alt="...">
                      <i class="online dot"></i>
                      <div class="media-body">
                        <h5 class="media-heading">Kehn Anderson</h5>
                        <div class="media-heading-sub">CEO</div>
                      </div>
                    </li>
                    <li class="media"><img class="media-object" src="<?php echo base_url();?>adminassets/assets/img/prof/prof2.jpg"
                        width="35" height="35" alt="...">
                      <i class="busy dot"></i>
                      <div class="media-body">
                        <h5 class="media-heading">Sarah Smith</h5>
                        <div class="media-heading-sub">Computer</div>
                      </div>
                    </li>
                    <li class="media"><img class="media-object" src="<?php echo base_url();?>adminassets/assets/img/prof/prof7.jpg"
                        width="35" height="35" alt="...">
                      <i class="online dot"></i>
                      <div class="media-body">
                        <h5 class="media-heading">Vlad Cardella</h5>
                        <div class="media-heading-sub">Cardiologist</div>
                      </div>
                    </li>
                  </ul>
                  <div class="chat-header">
                    <h5 class="list-heading">Offline</h5>
                  </div>
                  <ul class="media-list list-items">
                    <li class="media">
                      <div class="media-status">
                        <span class="badge badge-warning">4</span>
                      </div> <img class="media-object" src="<?php echo base_url();?>adminassets/assets/img/prof/prof6.jpg"
                        width="35" height="35" alt="...">
                      <i class="offline dot"></i>
                      <div class="media-body">
                        <h5 class="media-heading">Jennifer Maklen</h5>
                        <div class="media-heading-sub">Nurse</div>
                        <div class="media-heading-small">Last seen 01:20 AM</div>
                      </div>
                    </li>
                    <li class="media"><img class="media-object" src="<?php echo base_url();?>adminassets/assets/img/prof/prof8.jpg"
                        width="35" height="35" alt="...">
                      <i class="offline dot"></i>
                      <div class="media-body">
                        <h5 class="media-heading">Lina Smith</h5>
                        <div class="media-heading-sub">Ortho Surgeon</div>
                        <div class="media-heading-small">Last seen 11:14 PM</div>
                      </div>
                    </li>
                    <li class="media">
                      <div class="media-status">
                        <span class="badge badge-success">9</span>
                      </div> <img class="media-object" src="<?php echo base_url();?>adminassets/assets/img/prof/prof9.jpg"
                        width="35" height="35" alt="...">
                      <i class="offline dot"></i>
                      <div class="media-body">
                        <h5 class="media-heading">Jeff Adam</h5>
                        <div class="media-heading-sub">Compounder</div>
                        <div class="media-heading-small">Last seen 3:31 PM</div>
                      </div>
                    </li>
                    <li class="media"><img class="media-object" src="<?php echo base_url();?>adminassets/assets/img/prof/prof10.jpg"
                        width="35" height="35" alt="...">
                      <i class="offline dot"></i>
                      <div class="media-body">
                        <h5 class="media-heading">Anjelina Cardella</h5>
                        <div class="media-heading-sub">Physiotherapist</div>
                        <div class="media-heading-small">Last seen 7:45 PM</div>
                      </div>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
            <!-- End User Chat -->
            <!-- Start Setting Panel -->
            <div class="tab-pane chat-sidebar-settings" role="tabpanel" id="quick_sidebar_tab_3">
              <div class="chat-sidebar-settings-list slimscroll-style">
                <div class="chat-header">
                  <h5 class="list-heading">Layout Settings</h5>
                </div>
                <div class="chatpane inner-content ">
                  <div class="settings-list">
                    <div class="setting-item">
                      <div class="setting-text">Sidebar Position</div>
                      <div class="setting-set">
                        <select
                          class="sidebar-pos-option form-control input-inline input-sm input-small ">
                          <option value="left" selected="selected">Left</option>
                          <option value="right">Right</option>
                        </select>
                      </div>
                    </div>
                    <div class="setting-item">
                      <div class="setting-text">Header</div>
                      <div class="setting-set">
                        <select
                          class="page-header-option form-control input-inline input-sm input-small ">
                          <option value="fixed" selected="selected">Fixed</option>
                          <option value="default">Default</option>
                        </select>
                      </div>
                    </div>
                    <div class="setting-item">
                      <div class="setting-text">Footer</div>
                      <div class="setting-set">
                        <select
                          class="page-footer-option form-control input-inline input-sm input-small ">
                          <option value="fixed">Fixed</option>
                          <option value="default" selected="selected">Default</option>
                        </select>
                      </div>
                    </div>
                  </div>
                  <div class="chat-header">
                    <h5 class="list-heading">Account Settings</h5>
                  </div>
                  <div class="settings-list">
                    <div class="setting-item">
                      <div class="setting-text">Notifications</div>
                      <div class="setting-set">
                        <div class="switch">
                          <label class="mdl-switch mdl-js-switch mdl-js-ripple-effect"
                            for="switch-1">
                            <input type="checkbox" id="switch-1" class="mdl-switch__input"
                              checked>
                          </label>
                        </div>
                      </div>
                    </div>
                    <div class="setting-item">
                      <div class="setting-text">Show Online</div>
                      <div class="setting-set">
                        <div class="switch">
                          <label class="mdl-switch mdl-js-switch mdl-js-ripple-effect"
                            for="switch-7">
                            <input type="checkbox" id="switch-7" class="mdl-switch__input"
                              checked>
                          </label>
                        </div>
                      </div>
                    </div>
                    <div class="setting-item">
                      <div class="setting-text">Status</div>
                      <div class="setting-set">
                        <div class="switch">
                          <label class="mdl-switch mdl-js-switch mdl-js-ripple-effect"
                            for="switch-2">
                            <input type="checkbox" id="switch-2" class="mdl-switch__input"
                              checked>
                          </label>
                        </div>
                      </div>
                    </div>
                    <div class="setting-item">
                      <div class="setting-text">2 Steps Verification</div>
                      <div class="setting-set">
                        <div class="switch">
                          <label class="mdl-switch mdl-js-switch mdl-js-ripple-effect"
                            for="switch-3">
                            <input type="checkbox" id="switch-3" class="mdl-switch__input"
                              checked>
                          </label>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="chat-header">
                    <h5 class="list-heading">General Settings</h5>
                  </div>
                  <div class="settings-list">
                    <div class="setting-item">
                      <div class="setting-text">Location</div>
                      <div class="setting-set">
                        <div class="switch">
                          <label class="mdl-switch mdl-js-switch mdl-js-ripple-effect"
                            for="switch-4">
                            <input type="checkbox" id="switch-4" class="mdl-switch__input"
                              checked>
                          </label>
                        </div>
                      </div>
                    </div>
                    <div class="setting-item">
                      <div class="setting-text">Save Histry</div>
                      <div class="setting-set">
                        <div class="switch">
                          <label class="mdl-switch mdl-js-switch mdl-js-ripple-effect"
                            for="switch-5">
                            <input type="checkbox" id="switch-5" class="mdl-switch__input"
                              checked>
                          </label>
                        </div>
                      </div>
                    </div>
                    <div class="setting-item">
                      <div class="setting-text">Auto Updates</div>
                      <div class="setting-set">
                        <div class="switch">
                          <label class="mdl-switch mdl-js-switch mdl-js-ripple-effect"
                            for="switch-6">
                            <input type="checkbox" id="switch-6" class="mdl-switch__input"
                              checked>
                          </label>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- end chat sidebar -->
    </div>
    <!-- end page container -->
    <!-- Student Delete Modal -->
<div id="deleteModal" class="modal fade">
  <div class="modal-dialog modal-confirm">
    <div class="modal-content">
      <div class="modal-header">
        <!--<div class="icon-box">
          <i class="material-icons">&#xE5CD;</i>
        </div>-->        
        <h4 class="modal-title">Are you sure ?</h4>  
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
      </div>
      <div class="modal-body">
        <p>Do you really want to delete these records?<br> This process cannot be undone.</p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-info" data-dismiss="modal">Cancel</button>
        <button type="button" class="btn btn-danger" id="proceedDelete">Delete</button>
      </div>
    </div>
  </div>
</div> 

 <?php require_once('footer.php');?>  
</body>

<script type="text/javascript">
  var stuId='';
  $(document).ready(function(){
   $('.deleteStudent').on('click',function(){
       var studentId = $(this).data('id');      
       stuId = studentId;
       var proceed = true;
       if(studentId==''){
         proceed = false;
         return false;
       }
       if(proceed){
        $('#deleteModal').modal('show');
       }
   });

//=========== Student Delete Proceed JS START============//
   $('#proceedDelete').on('click',function(){
      var proceed = true;
     if(stuId==''){
         proceed = false;
         $('#alertMsg').html('<div class="alert alert-warning alert-dismissible"><button type="button" class="close" data-dismiss="alert">&times;</button><strong>Oops!</strong> Student id can not be empty.</div>');   
         return false;
     }
     if(proceed){
         $.ajax({
               type:'post',
               url:'<?php echo base_url()?>delete_student',
               data:{studentid:stuId},
               success:function(html){
                console.log(html);
                if($.trim(html)==='success'){
                  $('#deleteModal').modal('hide');
                  $('#alertMsg').html('<div class="alert alert-success alert-dismissible"><button type="button" class="close" data-dismiss="alert">&times;</button><strong>Success!</strong> Student Records Deleted Successfull.</div>');
                  $('#del_'+stuId).remove();
                }
               else if($.trim(html)==='db_error'){
                  $('#alertMsg').html('<div class="alert alert-warning alert-dismissible"><button type="button" class="close" data-dismiss="alert">&times;</button><strong>Oops!</strong> Database Error.</div>');
                }
               else if($.trim(html)==='id_error'){
                  $('#alertMsg').html('<div class="alert alert-warning alert-dismissible"><button type="button" class="close" data-dismiss="alert">&times;</button><strong>Oops!</strong> Student id can not be Empty.</div>');
                }
               else if($.trim(html)==='ajax_error'){
                  $('#alertMsg').html('<div class="alert alert-warning alert-dismissible"><button type="button" class="close" data-dismiss="alert">&times;</button><strong>Oops!</strong> This is not Ajax Request.</div>');
                }   
               }
         });
     }

   });

  });
</script>
