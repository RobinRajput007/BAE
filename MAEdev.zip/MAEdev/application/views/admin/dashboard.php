<?php require_once('header.php');?>

<body
  class="page-header-fixed sidemenu-closed-hidelogo page-content-white page-md header-white white-sidebar-color logo-indigo">
  <div class="page-wrapper">
    <!-- start header -->
    <div class="page-header navbar navbar-fixed-top">
      <div class="page-header-inner ">
        <!-- logo start -->
        <div class="page-logo">
          <a href="index.html">
            
            <span class="logo-default">BAE</span> </a>
        </div>
        <!-- logo end -->
        <ul class="nav navbar-nav navbar-left in">
          <li><a href="#" class="menu-toggler sidebar-toggler"><i class="icon-menu"></i></a></li>
        </ul>
        <form class="search-form-opened" action="#" method="GET">
          <div class="input-group">
            <input type="text" class="form-control" placeholder="Search Assignment" name="query">
            <span class="input-group-btn">
              <a href="javascript:;" class="btn submit">
                <i class="icon-magnifier"></i>
              </a>
            </span>
          </div>
        </form>
        
        <form class="search-form-opened" action="#" method="GET">
          <div class="input-group">
            <input type="text" class="form-control" placeholder="Search Student" name="query">
            <span class="input-group-btn">
              <a href="javascript:;" class="btn submit">
                <i class="icon-magnifier"></i>
              </a>
            </span>
          </div>
        </form>
        
        <form class="search-form-opened" action="#" method="GET">
          <div class="input-group">
            <input type="text" class="form-control" placeholder="Search Experts" name="query">
            <span class="input-group-btn">
              <a href="javascript:;" class="btn submit">
                <i class="icon-magnifier"></i>
              </a>
            </span>
          </div>
        </form>
        <!-- start mobile menu -->
        <a href="javascript:;" class="menu-toggler responsive-toggler" data-toggle="collapse"
          data-target=".navbar-collapse">
          <span></span>
        </a>
        <!-- end mobile menu -->
        <!-- start header menu -->
        <div class="top-menu">
          <ul class="nav navbar-nav pull-right">
            <!-- start language menu -->
            
            <!-- end language menu -->
            <!-- start notification dropdown -->
            <li class="dropdown dropdown-extended dropdown-notification" id="header_notification_bar">
              <a href="javascript:;" class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown"
                data-close-others="true">
                <i class="fa fa-bell-o"></i>
                <span class="badge headerBadgeColor1"> 6 </span>
              </a>
              <ul class="dropdown-menu">
                <li class="external">
                  <h3><span class="bold">Notifications</span></h3>
                  <span class="notification-label purple-bgcolor">New 6</span>
                </li>
                <li>
                  <ul class="dropdown-menu-list small-slimscroll-style" data-handle-color="#637283">
                    <li>
                      <a href="javascript:;">
                        <span class="time">just now</span>
                        <span class="details">
                          <span class="notification-icon circle deepPink-bgcolor"><i
                              class="fa fa-check"></i></span>
                          Congratulations!. </span>
                      </a>
                    </li>
                    <li>
                      <a href="javascript:;">
                        <span class="time">3 mins</span>
                        <span class="details">
                          <span class="notification-icon circle purple-bgcolor"><i
                              class="fa fa-user o"></i></span>
                          <b>John Micle </b>is now following you. </span>
                      </a>
                    </li>
                    <li>
                      <a href="javascript:;">
                        <span class="time">7 mins</span>
                        <span class="details">
                          <span class="notification-icon circle blue-bgcolor"><i
                              class="fa fa-comments-o"></i></span>
                          <b>Sneha Jogi </b>sent you a message. </span>
                      </a>
                    </li>
                    <li>
                      <a href="javascript:;">
                        <span class="time">12 mins</span>
                        <span class="details">
                          <span class="notification-icon circle pink"><i
                              class="fa fa-heart"></i></span>
                          <b>Ravi Patel </b>like your photo. </span>
                      </a>
                    </li>
                    <li>
                      <a href="javascript:;">
                        <span class="time">15 mins</span>
                        <span class="details">
                          <span class="notification-icon circle yellow"><i
                              class="fa fa-warning"></i></span> Warning! </span>
                      </a>
                    </li>
                    <li>
                      <a href="javascript:;">
                        <span class="time">10 hrs</span>
                        <span class="details">
                          <span class="notification-icon circle red"><i
                              class="fa fa-times"></i></span> Application error. </span>
                      </a>
                    </li>
                  </ul>
                  <div class="dropdown-menu-footer">
                    <a href="javascript:void(0)"> All notifications </a>
                  </div>
                </li>
              </ul>
            </li>
            <!-- end notification dropdown -->
            
            <!-- start manage user dropdown -->
            <li class="dropdown dropdown-user">
              <a href="javascript:;" class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown"
                data-close-others="true">
                <img alt="" class="img-circle " src="<?php echo base_url();?>adminassets/assets/img/dp.jpg" />
                <span class="username username-hide-on-mobile"> Kiran </span>
                <i class="fa fa-angle-down"></i>
              </a>
              <ul class="dropdown-menu dropdown-menu-default">
                <li>
                  <a href="user_profile.html">
                    <i class="icon-user"></i> Profile </a>
                </li>
                <li>
                  <a href="#">
                    <i class="icon-settings"></i> Settings
                  </a>
                </li>
                <li>
                  <a href="#">
                    <i class="icon-directions"></i> Help
                  </a>
                </li>
                <li class="divider"> </li>
                <li>
                  <a href="lock_screen.html">
                    <i class="icon-lock"></i> Lock
                  </a>
                </li>
                <li>
                  <a href="<?php echo base_url();?>admin_logout">
                    <i class="icon-logout"></i> Log Out </a>
                </li>
              </ul>
            </li>
            <!-- end manage user dropdown -->
            <li class="dropdown dropdown-quick-sidebar-toggler">
              <a id="headerSettingButton" class="mdl-button mdl-js-button mdl-button--icon pull-right"
                data-upgraded=",MaterialButton">
                <i class="material-icons">more_vert</i>
              </a>
            </li>
          </ul>
        </div>
      </div>
    </div>
    <!-- end header -->
  
    <!-- start page container -->
    <div class="page-container">
     <!-- start sidebar menu --> 
    <?php echo require_once('sidebar_menu.php');?>
      <!-- start page content -->
      <div class="page-content-wrapper">
        <div class="page-content">
          <div class="page-bar">
            <div class="page-title-breadcrumb">
              <div class=" pull-left">
                <div class="page-title">Dashboard</div>
              </div>
              <ol class="breadcrumb page-breadcrumb pull-right">
                <li><i class="fa fa-home"></i>&nbsp;<a class="parent-item"
                    href="index.html">Home</a>&nbsp;<i class="fa fa-angle-right"></i>
                </li>
                <li class="active">Dashboard</li>
              </ol>
            </div>
          </div>
          <!-- start widget -->
          <div class="state-overview">
            <div class="row">
              <div class="col-xl-3 col-md-6 col-12">
                <a href="<?php echo base_url();?>adminall_assignments">
                <div class="info-box bg-b-green">
                  <span class="info-box-icon push-bottom"><i class="material-icons">description</i></span>
                  <div class="info-box-content">
                    <span class="info-box-number">0</span>
                    <div class="progress">
                      <div class="progress-bar" style="width: 45%"></div>
                    </div>
                    <span class="progress-description">
                    All Assignments
                    </span>
                  </div>
                  <!-- /.info-box-content -->
                </div>
              </a>
                <!-- /.info-box -->
              </div>
              <!-- /.col -->
              <div class="col-xl-3 col-md-6 col-12">
                <div class="info-box bg-b-blue">
                  <span class="info-box-icon push-bottom"><i class="material-icons">group</i></span>
                  <div class="info-box-content">
                    <span class="info-box-number">52</span>
                    <div class="progress">
                      <div class="progress-bar" style="width: 85%"></div>
                    </div>
                    <span class="progress-description">
                    Recently Registered Students
                    </span>
                  </div>
                  <!-- /.info-box-content -->
                </div>
                <!-- /.info-box -->
              </div>
              
              <div class="col-xl-3 col-md-6 col-12">
                <a href="<?php echo base_url();?>all_students">
                <div class="info-box bg-b-yellow">
                  <span class="info-box-icon push-bottom"><i class="material-icons">group</i></span>
                  <div class="info-box-content">
                    <span class="info-box-number"><?php if(isset($studentData))echo count($studentData);else 0;?></span>
                    <div class="progress">
                      <div class="progress-bar" style="width: 40%"></div>
                    </div>
                    <span class="progress-description">
                      Total Students
                    </span>
                  </div>
                  <!-- /.info-box-content -->
                </div>
              </a>
                <!-- /.info-box -->
              </div>
              <!-- /.col -->
              
              <!-- /.col -->
              <div class="col-xl-3 col-md-6 col-12">
                <a href="<?php echo base_url();?>all_experts">
                <div class="info-box bg-b-pink">
                  <span class="info-box-icon push-bottom"><i
                      class="material-icons">group</i></span>
                  <div class="info-box-content">
                    <span class="info-box-number"><?php if(isset($expertData))echo count($expertData);else 0;?></span>
                    <div class="progress">
                      <div class="progress-bar" style="width: 50%"></div>
                    </div>
                    <span class="progress-description">
                      Total Experts
                    </span>
                  </div>
                  <!-- /.info-box-content -->
                </div>
              </a>
                <!-- /.info-box -->
              </div>
              <!-- /.col -->
            </div>
            
            
            
            <div class="row">
              <div class="col-xl-3 col-md-6 col-12">
                <div class="info-box bg-b-pink">
                  <span class="info-box-icon push-bottom"><i
                      class="material-icons">group</i></span>
                  <div class="info-box-content">
                    <span class="info-box-number">13</span>
                    <div class="progress">
                      <div class="progress-bar" style="width: 50%"></div>
                    </div>
                    <span class="progress-description">
                      Create Admin/Super Admin
                    </span>
                  </div>
                  <!-- /.info-box-content -->
                </div>
                <!-- /.info-box -->
              </div>
              
                <div class="col-xl-3 col-md-6 col-12">
                <div class="info-box bg-b-blue">
                  <span class="info-box-icon push-bottom"><i class="material-icons">monetization_on</i></span>
                  <div class="info-box-content">
                    <span class="info-box-number">52</span>
                    <div class="progress">
                      <div class="progress-bar" style="width: 85%"></div>
                    </div>
                    <span class="progress-description">
                    Payment link
                    </span>
                  </div>
                  <!-- /.info-box-content -->
                </div>
                <!-- /.info-box -->
              </div>
              <!-- /.col -->
              
              
                <div class="col-xl-3 col-md-6 col-12">
                <div class="info-box bg-b-yellow">
                  <span class="info-box-icon push-bottom"><i class="material-icons">school</i></span>
                  <div class="info-box-content">
                    <span class="info-box-number">155</span>
                    <div class="progress">
                      <div class="progress-bar" style="width: 40%"></div>
                    </div>
                    <span class="progress-description">
                      Campaign Management
                    </span>
                  </div>
                  <!-- /.info-box-content -->
                </div>
                <!-- /.info-box -->
              </div>
              <!-- /.col -->
              
              <div class="col-xl-3 col-md-6 col-12">
                <div class="info-box bg-b-green">
                  <span class="info-box-icon push-bottom"><i class="material-icons">description</i></span>
                  <div class="info-box-content">
                    <span class="info-box-number">450</span>
                    <div class="progress">
                      <div class="progress-bar" style="width: 45%"></div>
                    </div>
                    <span class="progress-description">
                  Create Manual Assignment
                    </span>
                  </div>
                  <!-- /.info-box-content -->
                </div>
                <!-- /.info-box -->
              </div>
              <!-- /.col -->
              
              
            
            
            </div>
            
            
            
            
          </div>
          <!-- end widget -->
        
          <!-- End course list -->
          <div class="row">
            <!-- Quick Mail start -->
            <div class="col-lg-6 col-md-12 col-sm-12 col-12">
              <div class="card-box">
                <div class="card-head">
                  <header>Paypal and Create Assignment</header>
                  <button id="demo_menu-lower-right"
                    class="mdl-button mdl-js-button mdl-button--icon pull-right"
                    data-upgraded=",MaterialButton">
                    <i class="material-icons">more_vert</i>
                  </button>
                  <ul class="mdl-menu mdl-menu--bottom-right mdl-js-menu mdl-js-ripple-effect"
                    data-mdl-for="demo_menu-lower-right">
                    <li class="mdl-menu__item"><i class="material-icons">assistant_photo</i>Action
                    </li>
                    <li class="mdl-menu__item"><i class="material-icons">print</i>Another action
                    </li>
                    <li class="mdl-menu__item"><i class="material-icons">favorite</i>Something else
                      here</li>
                  </ul>
                </div>
                <div class="card-body ">
                  <div class="mail-list">
                    <div class="compose-mail">
                      <form method="post">
                        <div class="form-group">
                          <label for="to" class="">To:</label>
                          <input type="text" tabindex="1" id="to" class="form-control">
                          <div class="compose-options">
                            <a onclick="$(this).hide(); $('#cc').parent().removeClass('hidden'); $('#cc').focus();"
                              href="javascript:;">Cc</a>
                            <a onclick="$(this).hide(); $('#bcc').parent().removeClass('hidden'); $('#bcc').focus();"
                              href="javascript:;">Bcc</a>
                          </div>
                        </div>
                        <div class="form-group hidden">
                          <label for="cc" class="">Cc:</label>
                          <input type="text" tabindex="2" id="cc" class="form-control">
                        </div>
                        <div class="form-group hidden">
                          <label for="bcc" class="">Bcc:</label>
                          <input type="text" tabindex="2" id="bcc" class="form-control">
                        </div>
                        <div class="form-group">
                          <label for="subject" class="">Subject:</label>
                          <input type="text" tabindex="1" id="subject" class="form-control">
                        </div>
                        <div>
                          <div id="summernote"></div>
                          <input type="file" class="default" multiple>
                        </div>
                        <!--   <div class="btn-group margin-top-20 ">
                                                  <button class="btn btn-primary btn-sm margin-right-10"><i class="fa fa-check"></i> Send</button>
                                              </div> -->
                        <div class="box-footer clearfix">
                          <button type="button"
                            class="mdl-button mdl-button--raised mdl-js-ripple-effect m-b-10 btn-primary pull-right">Send
                            <i class="fa fa-paper-plane-o"></i></button>
                        </div>
                      </form>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <!-- Quick Mail end -->
            <!-- Activity feed start -->
            <div class="col-lg-6 col-md-12 col-sm-12 col-12">
              <div class="card-box">
                <div class="card-head">
                  <header>Recent Notification</header>
                  <button id="feedMenu" class="mdl-button mdl-js-button mdl-button--icon pull-right"
                    data-upgraded=",MaterialButton">
                    <i class="material-icons">more_vert</i>
                  </button>
                  <ul class="mdl-menu mdl-menu--bottom-right mdl-js-menu mdl-js-ripple-effect"
                    data-mdl-for="feedMenu">
                    <li class="mdl-menu__item"><i class="material-icons">assistant_photo</i>Action
                    </li>
                    <li class="mdl-menu__item"><i class="material-icons">print</i>Another action
                    </li>
                    <li class="mdl-menu__item"><i class="material-icons">favorite</i>Something else
                      here</li>
                  </ul>
                </div>
                <div class="card-body ">
                  <ul class="feedBody">
                    <li class="active-feed">
                      <div class="feed-user-img">
                        <img src="<?php echo base_url();?>adminassets/assets/img/std/std1.jpg" class="img-radius "
                          alt="User-Profile-Image">
                      </div>
                      <h6>
                        <span class="feedLblStyle lblFileStyle">File</span> Sarah Smith <small
                          class="text-muted">6 hours ago</small>
                      </h6>
                      <p class="m-b-15 m-t-15">
                        hii John, I have upload doc related to task.
                      </p>
                    </li>
                    <li class="diactive-feed">
                      <div class="feed-user-img">
                        <img src="<?php echo base_url();?>adminassets/assets/img/std/std2.jpg" class="img-radius "
                          alt="User-Profile-Image">
                      </div>
                      <h6>
                        <span class="feedLblStyle lblTaskStyle">Task </span> Jalpa Joshi<small
                          class="text-muted">5 hours
                          ago</small>
                      </h6>
                      <p class="m-b-15 m-t-15">
                        Please do as specify. Let me know if you have any query.
                      </p>
                    </li>
                    <li class="diactive-feed">
                      <div class="feed-user-img">
                        <img src="<?php echo base_url();?>adminassets/assets/img/std/std3.jpg" class="img-radius "
                          alt="User-Profile-Image">
                      </div>
                      <h6>
                        <span class="feedLblStyle lblCommentStyle">comment</span> Lina
                        Smith<small class="text-muted">6 hours ago</small>
                      </h6>
                      <p class="m-b-15 m-t-15">
                        Hey, How are you??
                      </p>
                    </li>
                    <li class="active-feed">
                      <div class="feed-user-img">
                        <img src="<?php echo base_url();?>adminassets/assets/img/std/std4.jpg" class="img-radius "
                          alt="User-Profile-Image">
                      </div>
                      <h6>
                        <span class="feedLblStyle lblReplyStyle">Reply</span> Jacob Ryan
                        <small class="text-muted">7 hours ago</small>
                      </h6>
                      <p class="m-b-15 m-t-15">
                        I am fine. You??
                      </p>
                    </li>
                    <li class="active-feed">
                      <div class="feed-user-img">
                        <img src="<?php echo base_url();?>adminassets/assets/img/std/std5.jpg" class="img-radius "
                          alt="User-Profile-Image">
                      </div>
                      <h6>
                        <span class="feedLblStyle lblFileStyle">File</span> Sarah Smith <small
                          class="text-muted">6 hours ago</small>
                      </h6>
                      <p class="m-b-15 m-t-15">
                        hii John, I have upload doc related to task.
                      </p>
                    </li>
                    <li class="diactive-feed">
                      <div class="feed-user-img">
                        <img src="<?php echo base_url();?>adminassets/assets/img/std/std6.jpg" class="img-radius "
                          alt="User-Profile-Image">
                      </div>
                      <h6>
                        <span class="feedLblStyle lblTaskStyle">Task </span> Jalpa Joshi<small
                          class="text-muted">5 hours
                          ago</small>
                      </h6>
                      <p class="m-b-15 m-t-15">
                        Please do as specify. Let me know if you have any query.
                      </p>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
            <!-- Activity feed end -->
          </div>
          <div class="row">
            <div class="col-lg-6 col-md-12 col-sm-12 col-12">
              <div class="card-box">
                <div class="card-head">
                  <header>Recently Registered Users(15 show)</header>
                  <button id="panel-button8"
                    class="mdl-button mdl-js-button mdl-button--icon pull-right"
                    data-upgraded=",MaterialButton">
                    <i class="material-icons">more_vert</i>
                  </button>
                  <ul class="mdl-menu mdl-menu--bottom-right mdl-js-menu mdl-js-ripple-effect"
                    data-mdl-for="panel-button8">
                    <li class="mdl-menu__item"><i class="material-icons">assistant_photo</i>Action
                    </li>
                    <li class="mdl-menu__item"><i class="material-icons">print</i>Another action
                    </li>
                    <li class="mdl-menu__item"><i class="material-icons">favorite</i>Something else
                      here</li>
                  </ul>
                </div>
                <div class="card-body ">
                  <div class="table-responsive">
                    <table class="table table-striped custom-table table-hover">
                      <thead>
                        <tr>
                          <th>Roll No</th>
                          <th>Name</th>
                          <th>Graph</th>
                          <th>Action</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td>23</td>
                          <td>John Smith</td>
                          <td>
                            <div id="sparkline"></div>
                          </td>
                          <td><a href="javascript:void(0)" class="" data-toggle="tooltip"
                              title="Edit">
                              <i class="fa fa-check"></i></a>
                            <a href="javascript:void(0)" class="text-inverse" title="Delete"
                              data-toggle="tooltip">
                              <i class="fa fa-trash"></i></a>
                          </td>
                        </tr>
                        <tr>
                          <td>12</td>
                          <td>Sneha Pandit</td>
                          <td>
                            <div id="sparkline1"></div>
                          </td>
                          <td><a href="javascript:void(0)" class="" data-toggle="tooltip"
                              title="Edit">
                              <i class="fa fa-check"></i></a>
                            <a href="javascript:void(0)" class="text-inverse" title="Delete"
                              data-toggle="tooltip">
                              <i class="fa fa-trash"></i></a>
                          </td>
                        </tr>
                        <tr>
                          <td>45</td>
                          <td>Sarah Smith</td>
                          <td>
                            <div id="sparkline2"></div>
                          </td>
                          <td><a href="javascript:void(0)" class="" data-toggle="tooltip"
                              title="Edit">
                              <i class="fa fa-check"></i></a>
                            <a href="javascript:void(0)" class="text-inverse" title="Delete"
                              data-toggle="tooltip">
                              <i class="fa fa-trash"></i></a>
                          </td>
                        </tr>
                        <tr>
                          <td>34</td>
                          <td>John Deo</td>
                          <td>
                            <div id="sparkline3"></div>
                          </td>
                          <td><a href="javascript:void(0)" class="" data-toggle="tooltip"
                              title="Edit">
                              <i class="fa fa-check"></i></a>
                            <a href="javascript:void(0)" class="text-inverse" title="Delete"
                              data-toggle="tooltip">
                              <i class="fa fa-trash"></i></a>
                          </td>
                        </tr>
                        <tr>
                          <td>15</td>
                          <td>Jay Soni</td>
                          <td>
                            <div id="sparkline4"></div>
                          </td>
                          <td><a href="javascript:void(0)" class="" data-toggle="tooltip"
                              title="Edit">
                              <i class="fa fa-check"></i></a>
                            <a href="javascript:void(0)" class="text-inverse" title="Delete"
                              data-toggle="tooltip">
                              <i class="fa fa-trash"></i></a>
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-lg-6 col-md-12 col-sm-12 col-12">
              <div class="card-box">
                <div class="card-head">
                  <header>Todo List</header>
                  <button id="panel-button"
                    class="mdl-button mdl-js-button mdl-button--icon pull-right"
                    data-upgraded=",MaterialButton">
                    <i class="material-icons">more_vert</i>
                  </button>
                  <ul class="mdl-menu mdl-menu--bottom-right mdl-js-menu mdl-js-ripple-effect"
                    data-mdl-for="panel-button">
                    <li class="mdl-menu__item"><i class="material-icons">assistant_photo</i>Action
                    </li>
                    <li class="mdl-menu__item"><i class="material-icons">print</i>Another action
                    </li>
                    <li class="mdl-menu__item"><i class="material-icons">favorite</i>Something else
                      here</li>
                  </ul>
                </div>
                <div class="card-body ">
                  <ul class="to-do-list ui-sortable" id="sortable-todo">
                    <li class="clearfix">
                      <div class="todo-check pull-left">
                        <input type="checkbox" value="None" id="todo-check1">
                        <label for="todo-check1"></label>
                      </div>
                      <p class="todo-title">Add fees details in system
                      </p>
                      <div class="todo-actionlist pull-right clearfix">
                        <a href="#" class="todo-remove"><i class="fa fa-times"></i></a>
                      </div>
                    </li>
                    <li class="clearfix">
                      <div class="todo-check pull-left">
                        <input type="checkbox" value="None" id="todo-check2">
                        <label for="todo-check2"></label>
                      </div>
                      <p class="todo-title">Announcement for holiday
                      </p>
                      <div class="todo-actionlist pull-right clearfix">
                        <a href="#" class="todo-remove"><i class="fa fa-times"></i></a>
                      </div>
                    </li>
                    <li class="clearfix">
                      <div class="todo-check pull-left">
                        <input type="checkbox" value="None" id="todo-check3">
                        <label for="todo-check3"></label>
                      </div>
                      <p class="todo-title">call bus driver</p>
                      <div class="todo-actionlist pull-right clearfix">
                        <a href="#" class="todo-remove"><i class="fa fa-times"></i></a>
                      </div>
                    </li>
                    <li class="clearfix">
                      <div class="todo-check pull-left">
                        <input type="checkbox" value="None" id="todo-check4">
                        <label for="todo-check4"></label>
                      </div>
                      <p class="todo-title">School picnic</p>
                      <div class="todo-actionlist pull-right clearfix">
                        <a href="#" class="todo-remove"><i class="fa fa-times"></i></a>
                      </div>
                    </li>
                    <li class="clearfix">
                      <div class="todo-check pull-left">
                        <input type="checkbox" value="None" id="todo-check5">
                        <label for="todo-check5"></label>
                      </div>
                      <p class="todo-title">Exam time table generate
                      </p>
                      <div class="todo-actionlist pull-right clearfix">
                        <a href="#" class="todo-remove"><i class="fa fa-times"></i></a>
                      </div>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
          <!-- start new student list -->
          <div class="row">
            <div class="col-md-12 col-sm-12">
              <div class="card  card-box">
                <div class="card-head">
                  <header>Recent Assignments List</header>
                  <div class="tools">
                    <a class="fa fa-repeat btn-color box-refresh" href="javascript:;"></a>
                    <a class="t-collapse btn-color fa fa-chevron-down" href="javascript:;"></a>
                    <a class="t-close btn-color fa fa-times" href="javascript:;"></a>
                  </div>
                </div>
                <div class="card-body ">
                  <div class="table-wrap">
                    <div class="table-responsive">
                      <table class="table display product-overview mb-30 table-striped table-bordered table-hover" id="support_table">
                        <thead>
                          <tr>
                        <th>No</th>
                        <th>Assignments</th>
                        <th>Subjects</th>
                        <th>Total Amount</th>
                        <th>Payment Paid</th>
                        <th>Payment Left</th>
                        <th>Submitted date</th>
                        <th>Due date</th>
                        <th>Experts</th>
                        <th>Action</th>
                          </tr>
                        </thead>
                        <tbody>
                      
                          <tr>
                            <td>1</td>
                        <td><span class="label label-md label-warning">BAE-01082019-2058</span></td>
                        <td>Mechanical</td>
                        <td>150USD</td>
                        <td>75USD</td>
                        <td>75USD</td>
                        <td>2011/04/25</td>
                        <td>2011/04/25</td>
                        <td>Expert</td>
                            <td><a href="javascript:void(0)" class="" data-toggle="tooltip"
                                title="Edit"><i class="fa fa-check"></i></a>
                              <a href="javascript:void(0)" class="text-inverse"
                                title="Delete" data-toggle="tooltip"><i
                                  class="fa fa-trash"></i></a></td>
                          </tr>
                          <tr>
                            <td>1</td>
                        <td><span class="label label-md label-warning">BAE-01082019-2058</span></td>
                        <td>Mechanical</td>
                        <td>150USD</td>
                        <td>75USD</td>
                        <td>75USD</td>
                        <td>2011/04/25</td>
                        <td>2011/04/25</td>
                        <td>Expert</td>
                            <td><a href="javascript:void(0)" class="" data-toggle="tooltip"
                                title="Edit"><i class="fa fa-check"></i></a>
                              <a href="javascript:void(0)" class="text-inverse"
                                title="Delete" data-toggle="tooltip"><i
                                  class="fa fa-trash"></i></a></td>
                          </tr>
                          
                              <tr>
                            <td>1</td>
                        <td><span class="label label-md label-warning">BAE-01082019-2058</span></td>
                        <td>Mechanical</td>
                        <td>150USD</td>
                        <td>75USD</td>
                        <td>75USD</td>
                        <td>2011/04/25</td>
                        <td>2011/04/25</td>
                        <td>Expert</td>
                            <td><a href="javascript:void(0)" class="" data-toggle="tooltip"
                                title="Edit"><i class="fa fa-check"></i></a>
                              <a href="javascript:void(0)" class="text-inverse"
                                title="Delete" data-toggle="tooltip"><i
                                  class="fa fa-trash"></i></a></td>
                          </tr>
                        
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <!-- end new student list -->
        </div>
      </div>
      <!-- end page content -->
      <!-- start chat sidebar -->
      <div class="chat-sidebar-container" data-close-on-body-click="false">
        <div class="chat-sidebar">
          <ul class="nav nav-tabs">
            <li class="nav-item">
              <a href="#quick_sidebar_tab_1" class="nav-link active tab-icon" data-toggle="tab"> <i
                  class="material-icons">chat</i>Chat
                <span class="badge badge-danger">4</span>
              </a>
            </li>
            <li class="nav-item">
              <a href="#quick_sidebar_tab_3" class="nav-link tab-icon" data-toggle="tab"> <i
                  class="material-icons">settings</i>
                Settings
              </a>
            </li>
          </ul>
          <div class="tab-content">
            <!-- Start User Chat -->
            <div class="tab-pane active chat-sidebar-chat in active show" role="tabpanel"
              id="quick_sidebar_tab_1">
              <div class="chat-sidebar-list">
                <div class="chat-sidebar-chat-users slimscroll-style" data-rail-color="#ddd"
                  data-wrapper-class="chat-sidebar-list">
                  <div class="chat-header">
                    <h5 class="list-heading">Online</h5>
                  </div>
                  <ul class="media-list list-items">
                    <li class="media"><img class="media-object" src="<?php echo base_url();?>adminassets/assets/img/prof/prof3.jpg"
                        width="35" height="35" alt="...">
                      <i class="online dot"></i>
                      <div class="media-body">
                        <h5 class="media-heading">John Deo</h5>
                        <div class="media-heading-sub">Spine Surgeon</div>
                      </div>
                    </li>
                    <li class="media">
                      <div class="media-status">
                        <span class="badge badge-success">5</span>
                      </div> <img class="media-object" src="<?php echo base_url();?>adminassets/assets/img/prof/prof1.jpg"
                        width="35" height="35" alt="...">
                      <i class="busy dot"></i>
                      <div class="media-body">
                        <h5 class="media-heading">Rajesh</h5>
                        <div class="media-heading-sub">Director</div>
                      </div>
                    </li>
                    <li class="media"><img class="media-object" src="<?php echo base_url();?>adminassets/assets/img/prof/prof5.jpg"
                        width="35" height="35" alt="...">
                      <i class="away dot"></i>
                      <div class="media-body">
                        <h5 class="media-heading">Jacob Ryan</h5>
                        <div class="media-heading-sub">Ortho Surgeon</div>
                      </div>
                    </li>
                    <li class="media">
                      <div class="media-status">
                        <span class="badge badge-danger">8</span>
                      </div> <img class="media-object" src="<?php echo base_url();?>adminassets/assets/img/prof/prof4.jpg"
                        width="35" height="35" alt="...">
                      <i class="online dot"></i>
                      <div class="media-body">
                        <h5 class="media-heading">Kehn Anderson</h5>
                        <div class="media-heading-sub">CEO</div>
                      </div>
                    </li>
                    <li class="media"><img class="media-object" src="<?php echo base_url();?>adminassets/assets/img/prof/prof2.jpg"
                        width="35" height="35" alt="...">
                      <i class="busy dot"></i>
                      <div class="media-body">
                        <h5 class="media-heading">Sarah Smith</h5>
                        <div class="media-heading-sub">Anaesthetics</div>
                      </div>
                    </li>
                    <li class="media"><img class="media-object" src="<?php echo base_url();?>adminassets/assets/img/prof/prof7.jpg"
                        width="35" height="35" alt="...">
                      <i class="online dot"></i>
                      <div class="media-body">
                        <h5 class="media-heading">Vlad Cardella</h5>
                        <div class="media-heading-sub">Cardiologist</div>
                      </div>
                    </li>
                  </ul>
                  <div class="chat-header">
                    <h5 class="list-heading">Offline</h5>
                  </div>
                  <ul class="media-list list-items">
                    <li class="media">
                      <div class="media-status">
                        <span class="badge badge-warning">4</span>
                      </div> <img class="media-object" src="<?php echo base_url();?>adminassets/assets/img/prof/prof6.jpg"
                        width="35" height="35" alt="...">
                      <i class="offline dot"></i>
                      <div class="media-body">
                        <h5 class="media-heading">Jennifer Maklen</h5>
                        <div class="media-heading-sub">Nurse</div>
                        <div class="media-heading-small">Last seen 01:20 AM</div>
                      </div>
                    </li>
                    <li class="media"><img class="media-object" src="<?php echo base_url();?>adminassets/assets/img/prof/prof8.jpg"
                        width="35" height="35" alt="...">
                      <i class="offline dot"></i>
                      <div class="media-body">
                        <h5 class="media-heading">Lina Smith</h5>
                        <div class="media-heading-sub">Ortho Surgeon</div>
                        <div class="media-heading-small">Last seen 11:14 PM</div>
                      </div>
                    </li>
                    <li class="media">
                      <div class="media-status">
                        <span class="badge badge-success">9</span>
                      </div> <img class="media-object" src="<?php echo base_url();?>adminassets/assets/img/prof/prof9.jpg"
                        width="35" height="35" alt="...">
                      <i class="offline dot"></i>
                      <div class="media-body">
                        <h5 class="media-heading">Jeff Adam</h5>
                        <div class="media-heading-sub">Compounder</div>
                        <div class="media-heading-small">Last seen 3:31 PM</div>
                      </div>
                    </li>
                    <li class="media"><img class="media-object" src="<?php echo base_url();?>adminassets/assets/img/prof/prof10.jpg"
                        width="35" height="35" alt="...">
                      <i class="offline dot"></i>
                      <div class="media-body">
                        <h5 class="media-heading">Anjelina Cardella</h5>
                        <div class="media-heading-sub">Physiotherapist</div>
                        <div class="media-heading-small">Last seen 7:45 PM</div>
                      </div>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
            <!-- End User Chat -->
            <!-- Start Setting Panel -->
            <div class="tab-pane chat-sidebar-settings" role="tabpanel" id="quick_sidebar_tab_3">
              <div class="chat-sidebar-settings-list slimscroll-style">
                <div class="chat-header">
                  <h5 class="list-heading">Layout Settings</h5>
                </div>
                <div class="chatpane inner-content ">
                  <div class="settings-list">
                    <div class="setting-item">
                      <div class="setting-text">Sidebar Position</div>
                      <div class="setting-set">
                        <select
                          class="sidebar-pos-option form-control input-inline input-sm input-small ">
                          <option value="left" selected="selected">Left</option>
                          <option value="right">Right</option>
                        </select>
                      </div>
                    </div>
                    <div class="setting-item">
                      <div class="setting-text">Header</div>
                      <div class="setting-set">
                        <select
                          class="page-header-option form-control input-inline input-sm input-small ">
                          <option value="fixed" selected="selected">Fixed</option>
                          <option value="default">Default</option>
                        </select>
                      </div>
                    </div>
                    <div class="setting-item">
                      <div class="setting-text">Footer</div>
                      <div class="setting-set">
                        <select
                          class="page-footer-option form-control input-inline input-sm input-small ">
                          <option value="fixed">Fixed</option>
                          <option value="default" selected="selected">Default</option>
                        </select>
                      </div>
                    </div>
                  </div>
                  <div class="chat-header">
                    <h5 class="list-heading">Account Settings</h5>
                  </div>
                  <div class="settings-list">
                    <div class="setting-item">
                      <div class="setting-text">Notifications</div>
                      <div class="setting-set">
                        <div class="switch">
                          <label class="mdl-switch mdl-js-switch mdl-js-ripple-effect"
                            for="switch-1">
                            <input type="checkbox" id="switch-1" class="mdl-switch__input"
                              checked>
                          </label>
                        </div>
                      </div>
                    </div>
                    <div class="setting-item">
                      <div class="setting-text">Show Online</div>
                      <div class="setting-set">
                        <div class="switch">
                          <label class="mdl-switch mdl-js-switch mdl-js-ripple-effect"
                            for="switch-7">
                            <input type="checkbox" id="switch-7" class="mdl-switch__input"
                              checked>
                          </label>
                        </div>
                      </div>
                    </div>
                    <div class="setting-item">
                      <div class="setting-text">Status</div>
                      <div class="setting-set">
                        <div class="switch">
                          <label class="mdl-switch mdl-js-switch mdl-js-ripple-effect"
                            for="switch-2">
                            <input type="checkbox" id="switch-2" class="mdl-switch__input"
                              checked>
                          </label>
                        </div>
                      </div>
                    </div>
                    <div class="setting-item">
                      <div class="setting-text">2 Steps Verification</div>
                      <div class="setting-set">
                        <div class="switch">
                          <label class="mdl-switch mdl-js-switch mdl-js-ripple-effect"
                            for="switch-3">
                            <input type="checkbox" id="switch-3" class="mdl-switch__input"
                              checked>
                          </label>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="chat-header">
                    <h5 class="list-heading">General Settings</h5>
                  </div>
                  <div class="settings-list">
                    <div class="setting-item">
                      <div class="setting-text">Location</div>
                      <div class="setting-set">
                        <div class="switch">
                          <label class="mdl-switch mdl-js-switch mdl-js-ripple-effect"
                            for="switch-4">
                            <input type="checkbox" id="switch-4" class="mdl-switch__input"
                              checked>
                          </label>
                        </div>
                      </div>
                    </div>
                    <div class="setting-item">
                      <div class="setting-text">Save Histry</div>
                      <div class="setting-set">
                        <div class="switch">
                          <label class="mdl-switch mdl-js-switch mdl-js-ripple-effect"
                            for="switch-5">
                            <input type="checkbox" id="switch-5" class="mdl-switch__input"
                              checked>
                          </label>
                        </div>
                      </div>
                    </div>
                    <div class="setting-item">
                      <div class="setting-text">Auto Updates</div>
                      <div class="setting-set">
                        <div class="switch">
                          <label class="mdl-switch mdl-js-switch mdl-js-ripple-effect"
                            for="switch-6">
                            <input type="checkbox" id="switch-6" class="mdl-switch__input"
                              checked>
                          </label>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- end chat sidebar -->
    </div>
    <!-- end page container -->    
  <?php require_once('footer.php');?>  
</body>
