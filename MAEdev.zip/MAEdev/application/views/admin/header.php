<!DOCTYPE html>
<html lang="en">
<!-- BEGIN HEAD -->
<head>
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta content="width=device-width, initial-scale=1" name="viewport" />
  <meta name="description" content="Responsive Admin Template" />
  <meta name="author" content="SmartUniversity" />
  <title>Home</title>
  <!-- google font -->
  <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700" rel="stylesheet" type="text/css" />
  <!-- icons -->
  <link href="<?php echo base_url();?>adminassets/fonts/simple-line-icons/simple-line-icons.min.css" rel="stylesheet" type="text/css" />
  <link href="<?php echo base_url();?>adminassets/fonts/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
  <link href="<?php echo base_url();?>adminassets/fonts/material-design-icons/material-icon.css" rel="stylesheet" type="text/css" />
  <!--bootstrap -->
  <link href="<?php echo base_url();?>adminassets/assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
  <link href="<?php echo base_url();?>adminassets/assets/plugins/datatables/plugins/bootstrap/dataTables.bootstrap4.min.css" rel="stylesheet" type="text/css" />

  <link href="<?php echo base_url();?>adminassets/assets/plugins/summernote/summernote.css" rel="stylesheet">
  <!-- Material Design Lite CSS -->
  <link rel="stylesheet" href="<?php echo base_url();?>adminassets/assets/plugins/material/material.min.css">
  <link rel="stylesheet" href="<?php echo base_url();?>adminassets/assets/css/material_style.css">
  <!-- inbox style -->
  <link href="<?php echo base_url();?>adminassets/assets/css/pages/inbox.min.css" rel="stylesheet" type="text/css" />
  <!-- Theme Styles -->
  <link href="<?php echo base_url();?>adminassets/assets/css/theme/hover/theme_style.css" rel="stylesheet" id="rt_style_components" type="text/css" />
  <link href="<?php echo base_url();?>adminassets/assets/css/plugins.min.css" rel="stylesheet" type="text/css" />
  <link href="<?php echo base_url();?>adminassets/assets/css/theme/hover/style.css" rel="stylesheet" type="text/css" />
  <link href="<?php echo base_url();?>adminassets/assets/css/responsive.css" rel="stylesheet" type="text/css" />
  <link href="<?php echo base_url();?>adminassets/assets/css/theme/hover/theme-color.css" rel="stylesheet" type="text/css" />
  <!-- favicon -->
  <link rel="shortcut icon" href="" />
</head>
<!-- END HEAD -->