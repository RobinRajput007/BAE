<!DOCTYPE html>
<html lang="en">
<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Best Assignment Experts Login</title>
  <!-- plugins:css -->
  <link rel="stylesheet" href="<?php echo base_url();?>assets/css/ti-icons/css/themify-icons.css">
  <link rel="stylesheet" href="<?php echo base_url();?>assets/css/vendor.bundle.base.css">
   <link rel="stylesheet" href="<?php echo base_url();?>assets/css/style.css">
   <link rel="stylesheet" href="<?php echo base_url();?>assets/css/auth.css">
   <link rel="stylesheet" href="<?php echo base_url();?>assets/vendors/datatables.net-bs4/dataTables.bootstrap4.css">
  <!-- endinject -->

</head>
